package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "listingamenities")
public class ListingAmenitiesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "listing_amenity_id")
    private int ListingAmenityId;
    @Column(name = "lease_listing_id")
    private int LeaseListingId;
    @Column(name = "amenity_id")
    private int AmenityId;

    public ListingAmenitiesEntity() {
    }

    public ListingAmenitiesEntity(int leaseListingId, int amenityId) {
        LeaseListingId = leaseListingId;
        AmenityId = amenityId;
    }

    public int getListingAmenityId() {
        return ListingAmenityId;
    }

    public void setListingAmenityId(int listingAmenityId) {
        ListingAmenityId = listingAmenityId;
    }

    public int getLeaseListingId() {
        return LeaseListingId;
    }

    public void setLeaseListingId(int leaseListingId) {
        LeaseListingId = leaseListingId;
    }

    public int getAmenityId() {
        return AmenityId;
    }

    public void setAmenityId(int amenityId) {
        AmenityId = amenityId;
    }


}
