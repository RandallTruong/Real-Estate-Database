package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "zipcodes")
public class ZipcodesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name="zipcode_id")
    private int ZipcodeId;
    @Column(name = "zipcode")
    private String Zipcode;

    public ZipcodesEntity() {
    }

    public ZipcodesEntity(String zipcode) {
        Zipcode = zipcode;
    }


    public int getZipcodeId() {
        return ZipcodeId;
    }

    public void setZipcodeId(int zipcodeId) {
        ZipcodeId = zipcodeId;
    }

    public String getZipcode() {
        return Zipcode;
    }

    public void setZipcode(String zipcode) {
        Zipcode = zipcode;
    }
}
