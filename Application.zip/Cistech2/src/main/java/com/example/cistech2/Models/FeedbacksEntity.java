package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "feedbacks")
public class FeedbacksEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "feedback_id")
    private int FeedbackId;
    @Column(name = "course_id")
    private int CourseId;
    @Column(name = "rating_id")
    private int RatingId;
    @Column(name = "date")
    private String Date;
    @Column(name = "comments")
    private String Comments;


    public FeedbacksEntity() {
    }

    public FeedbacksEntity(int courseId, int ratingId, String date, String comments) {
        CourseId = courseId;
        RatingId = ratingId;
        Date = date;
        Comments = comments;
    }

    public int getFeedbackId() {
        return FeedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        FeedbackId = feedbackId;
    }

    public int getCourseId() {
        return CourseId;
    }

    public void setCourseId(int courseId) {
        CourseId = courseId;
    }

    public int getRatingId() {
        return RatingId;
    }

    public void setRatingId(int ratingId) {
        RatingId = ratingId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getComments() {
        return Comments;
    }

    public void setComments(String comments) {
        Comments = comments;
    }
}
