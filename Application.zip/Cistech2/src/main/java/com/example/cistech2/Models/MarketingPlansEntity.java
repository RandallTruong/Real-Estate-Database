package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "marketingplans")
public class MarketingPlansEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "plan_id")
    private int PlanId;
    @Column(name = "listing_id")
    private int ListingId;
    @Column(name = "agent_id")
    private int AgentId;
    @Column(name = "campaign_id")
    private int CampaignId;
    @Column(name = "date")
    private String Date;
    @Column(name = "source")
    private String Source;
    @Column(name = "format")
    private String Format;
    @Column(name = "goal")
    private String Goal;


    public MarketingPlansEntity() {
    }

    public MarketingPlansEntity(int listingId, int agentId, int campaignId, String date,
                                String source, String format, String goal) {
        ListingId = listingId;
        AgentId = agentId;
        CampaignId = campaignId;
        Date = date;
        Source = source;
        Format = format;
        Goal = goal;
    }

    public int getPlanId() {
        return PlanId;
    }

    public void setPlanId(int planId) {
        PlanId = planId;
    }

    public int getListingId() {
        return ListingId;
    }

    public void setListingId(int listingId) {
        ListingId = listingId;
    }

    public int getAgentId() {
        return AgentId;
    }

    public void setAgentId(int agentId) {
        AgentId = agentId;
    }

    public int getCampaignId() {
        return CampaignId;
    }

    public void setCampaignId(int campaignId) {
        CampaignId = campaignId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getSource() {
        return Source;
    }

    public void setSource(String source) {
        Source = source;
    }

    public String getFormat() {
        return Format;
    }

    public void setFormat(String format) {
        Format = format;
    }

    public String getGoal() {
        return Goal;
    }

    public void setGoal(String goal) {
        Goal = goal;
    }

}
