package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "probationperiods")
public class ProbationPeriodsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name="probation_id")
    private int ProbationId;
    @Column(name = "team_member_id")
    private int TeamMemberId;
    @Column(name = "probation_start_date")
    private String ProbationStartDate;
    @Column(name = "probation_end_date")
    private String ProbationEndDate;
    @Column(name="number_of_transactions")
    private int NumberOfTransactions;
    @Column(name ="notes")
    private String Notes;


    public ProbationPeriodsEntity() {
    }

    public ProbationPeriodsEntity(int teamMemberId, String probationStartDate,
                                  String probationEndDate, int numberOfTransactions, String notes) {
        TeamMemberId = teamMemberId;
        ProbationStartDate = probationStartDate;
        ProbationEndDate = probationEndDate;
        NumberOfTransactions = numberOfTransactions;
        Notes = notes;
    }

    public int getProbationId() {
        return ProbationId;
    }

    public void setProbationId(int probationId) {
        ProbationId = probationId;
    }

    public int getTeamMemberId() {
        return TeamMemberId;
    }

    public void setTeamMemberId(int teamMemberId) {
        TeamMemberId = teamMemberId;
    }

    public String getProbationStartDate() {
        return ProbationStartDate;
    }

    public void setProbationStartDate(String probationStartDate) {
        ProbationStartDate = probationStartDate;
    }

    public String getProbationEndDate() {
        return ProbationEndDate;
    }

    public void setProbationEndDate(String probationEndDate) {
        ProbationEndDate = probationEndDate;
    }

    public int getNumberOfTransactions() {
        return NumberOfTransactions;
    }

    public void setNumberOfTransactions(int numberOfTransactions) {
        NumberOfTransactions = numberOfTransactions;
    }

    public String getNotes() {
        return Notes;
    }

    public void setNotes(String notes) {
        Notes = notes;
    }
}
