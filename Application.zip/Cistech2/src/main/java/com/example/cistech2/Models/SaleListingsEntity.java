package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "salelistings")
public class SaleListingsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name="sale_listing_id")
    private int SaleListingId;
    @Column(name = "listing_id")
    private int ListingId;
    @Column(name = "status_id")
    private int StatusId;
    @Column(name = "listing_price")
    private float ListingPrice;
    @Column(name = "year_built")
    private String YearBuilt;
    @Column(name = "christies_listing")
    private String ChristiesListing;
    @Column(name = "date")
    private String Date;


    public SaleListingsEntity() {
    }

    public SaleListingsEntity(int listingId, int statusId, float listingPrice,
                              String yearBuilt, String christiesListing, String date) {
        ListingId = listingId;
        StatusId = statusId;
        ListingPrice = listingPrice;
        YearBuilt = yearBuilt;
        ChristiesListing = christiesListing;
        Date = date;

    }

    public int getSaleListingId() {
        return SaleListingId;
    }

    public void setSaleListingId(int saleListingId) {
        SaleListingId = saleListingId;
    }

    public int getListingId() {
        return ListingId;
    }

    public void setListingId(int listingId) {
        ListingId = listingId;
    }

    public int getStatusId() {
        return StatusId;
    }

    public void setStatusId(int statusId) {
        StatusId = statusId;
    }

    public float getListingPrice() {
        return ListingPrice;
    }

    public void setListingPrice(float listingPrice) {
        ListingPrice = listingPrice;
    }

    public String getYearBuilt() {
        return YearBuilt;
    }

    public void setYearBuilt(String yearBuilt) {
        YearBuilt = yearBuilt;
    }

    public String getChristiesListing() {
        return ChristiesListing;
    }

    public void setChristiesListing(String christiesListing) {
        ChristiesListing = christiesListing;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
