package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "appointmenttopics")
public class AppointmentTopicsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "topic_id")
    private int TopicId;
    @Column(name = "topic")
    private String Topic;

    public AppointmentTopicsEntity(){

    }

    public AppointmentTopicsEntity(String topic) {
        Topic = topic;
    }


    public int getTopicId() {
        return TopicId;
    }

    public void setTopicId(int topicId) {
        TopicId = topicId;
    }

    public String getTopic() {
        return Topic;
    }

    public void setTopic(String topic) {
        Topic = topic;
    }


}
