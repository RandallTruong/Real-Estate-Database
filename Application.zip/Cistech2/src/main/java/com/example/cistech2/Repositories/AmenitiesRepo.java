package com.example.cistech2.Repositories;

import com.example.cistech2.Models.AmenitiesEntity;
import org.springframework.data.repository.CrudRepository;

public interface AmenitiesRepo extends CrudRepository<AmenitiesEntity, Integer> {

}