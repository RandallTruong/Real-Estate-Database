package com.example.cistech2.Repositories;


import com.example.cistech2.Models.AppointmentTopicsEntity;
import org.springframework.data.repository.CrudRepository;

public interface AppointmentTopicsRepo extends CrudRepository<AppointmentTopicsEntity, Integer> {

}