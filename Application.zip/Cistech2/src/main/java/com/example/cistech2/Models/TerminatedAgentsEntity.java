package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "terminatedagents")
public class TerminatedAgentsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "termination_id")
    private int TerminationId;
    @Column(name = "company_id")
    private int CompanyId;
    @Column(name = "first_name")
    private String FirstName;
    @Column(name = "last_name")
    private String LastName;
    @Column (name = "termination_date")
    private String TerminationDate;
    @Column (name = "explanation")
    private String Explanation;

    public TerminatedAgentsEntity() {
    }

    public TerminatedAgentsEntity(int companyId, String firstName,
                                  String lastName, String terminationDate, String explanation) {
        CompanyId = companyId;
        FirstName = firstName;
        LastName = lastName;
        TerminationDate = terminationDate;
        Explanation = explanation;
    }

    public int getTerminationId() {
        return TerminationId;
    }

    public void setTerminationId(int terminationId) {
        TerminationId = terminationId;
    }

    public int getCompanyId() {
        return CompanyId;
    }

    public void setCompanyId(int companyId) {
        CompanyId = companyId;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getTerminationDate() {
        return TerminationDate;
    }

    public void setTerminationDate(String terminationDate) {
        TerminationDate = terminationDate;
    }

    public String getExplanation() {
        return Explanation;
    }

    public void setExplanation(String explanation) {
        Explanation = explanation;
    }

}
