package com.example.cistech2.Repositories;

import com.example.cistech2.Models.PaymentTypesEntity;
import org.springframework.data.repository.CrudRepository;

public interface PaymentTypesRepo extends CrudRepository<PaymentTypesEntity, Integer> {

}