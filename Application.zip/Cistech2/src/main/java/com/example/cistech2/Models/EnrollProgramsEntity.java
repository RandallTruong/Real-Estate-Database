package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "enrollprograms")
public class EnrollProgramsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Id
  @Column(name = "enroll_id")
    private int EnrollId;
  @Column(name = "program_id")
    private int ProgramId;
  @Column(name = "Employee_id")
    private int EmployeeId;
  @Column(name = "date")
    private String date;

    public EnrollProgramsEntity() {
    }


    public EnrollProgramsEntity(int programId, int employeeId, String date) {
        ProgramId = programId;
        EmployeeId = employeeId;
        this.date = date;
    }

    public int getEnrollId() {
        return EnrollId;
    }

    public void setEnrollId(int enrollId) {
        EnrollId = enrollId;
    }

    public int getProgramId() {
        return ProgramId;
    }

    public void setProgramId(int programId) {
        ProgramId = programId;
    }

    public int getEmployeeId() {
        return EmployeeId;
    }

    public void setEmployeeId(int employeeId) {
        EmployeeId = employeeId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


}
