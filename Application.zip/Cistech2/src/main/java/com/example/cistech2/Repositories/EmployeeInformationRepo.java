package com.example.cistech2.Repositories;

import com.example.cistech2.Models.EmployeeInformationEntity;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeInformationRepo extends CrudRepository<EmployeeInformationEntity, Integer> {

}
