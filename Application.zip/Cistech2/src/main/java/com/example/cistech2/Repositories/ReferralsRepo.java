package com.example.cistech2.Repositories;

import com.example.cistech2.Models.ReferralsEntity;
import org.springframework.data.repository.CrudRepository;

public interface ReferralsRepo extends CrudRepository<ReferralsEntity, Integer> {

}
