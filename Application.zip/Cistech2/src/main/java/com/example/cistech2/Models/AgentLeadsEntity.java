package com.example.cistech2.Models;

import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "agentleads")
public class AgentLeadsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "agent_lead_id")
    private int AgentLeadId;
    @Column(name = "agent_id")
    private int AgentId;
    @Column(name = "first_name")
    private String FirstName;
    @Column(name= "last_name")
    private String LastName;
    @Column(name = "phone_number")
    private String PhoneNumber;
    @Column(name = "email")
    private String Email;
    @Column(name = "split_percentage")
    private String SplitPercentage;


    public AgentLeadsEntity(){

    }

    public AgentLeadsEntity( int agentId, String firstName, String lastName, String phoneNumber, String email, String splitPercentage) {

        AgentId = agentId;
        FirstName = firstName;
        LastName = lastName;
        PhoneNumber = phoneNumber;
        Email = email;
        SplitPercentage = splitPercentage;
    }


    public int getAgentLeadId() {
        return AgentLeadId;
    }

    public void setAgentLeadId(int agentLeadId) {
        AgentLeadId = agentLeadId;
    }

    public int getAgentId() {
        return AgentId;
    }

    public void setAgentId(int agentId) {
        AgentId = agentId;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getSplitPercentage() {
        return SplitPercentage;
    }

    public void setSplitPercentage(String splitPercentage) {
        SplitPercentage = splitPercentage;
    }



}
