package com.example.cistech2.Repositories;

import com.example.cistech2.Models.ComplaintsEntity;
import org.springframework.data.repository.CrudRepository;

public interface ComplaintsRepo extends CrudRepository<ComplaintsEntity, Integer> {

}