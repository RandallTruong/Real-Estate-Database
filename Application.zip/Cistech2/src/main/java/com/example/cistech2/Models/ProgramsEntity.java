package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "programs")
public class ProgramsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "program_id")
    private int ProgramId;
    @Column(name = "company_id")
    private int CompanyId;
    @Column(name = "title")
    private String title;

    public ProgramsEntity() {
    }

    public ProgramsEntity(int companyid, String title) {
        CompanyId = companyid;
        this.title = title;
    }


    public int getProgramId() {
        return ProgramId;
    }

    public void setProgramId(int programId) {
        ProgramId = programId;
    }

    public int getCompanyId() {
        return CompanyId;
    }

    public void setCompanyId(int company_id) {
        CompanyId = company_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
