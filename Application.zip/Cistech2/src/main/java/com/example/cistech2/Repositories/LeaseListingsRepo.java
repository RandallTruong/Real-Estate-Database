package com.example.cistech2.Repositories;

import com.example.cistech2.Models.LeaseListingsEntity;
import org.springframework.data.repository.CrudRepository;

public interface LeaseListingsRepo extends CrudRepository<LeaseListingsEntity, Integer> {

}
