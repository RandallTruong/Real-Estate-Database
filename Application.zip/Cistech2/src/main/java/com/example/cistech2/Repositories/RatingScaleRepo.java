package com.example.cistech2.Repositories;

import com.example.cistech2.Models.RatingScaleEntity;
import org.springframework.data.repository.CrudRepository;

public interface RatingScaleRepo extends CrudRepository<RatingScaleEntity, Integer> {

}