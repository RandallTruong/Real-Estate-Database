package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "infractions")
public class InfractionsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "infraction_id")
    private int InfractionId;
    @Column(name = "team_member_id")
    private int TeamMemberId;
    @Column(name = "nature_of_infraction")
    private String NatureOfInfraction;
    @Column(name = "Explanation")
    private String Explanation;
    @Column(name = "Date")
    private String Date;


    public InfractionsEntity() {
    }

    public InfractionsEntity(int teamMemberId, String natureOfInfraction,
                             String explanation, String date) {
        TeamMemberId = teamMemberId;
        NatureOfInfraction = natureOfInfraction;
        Explanation = explanation;
        Date = date;
    }

    public int getInfractionId() {
        return InfractionId;
    }

    public void setInfractionId(int infractionId) {
        InfractionId = infractionId;
    }

    public int getTeamMemberId() {
        return TeamMemberId;
    }

    public void setTeamMemberId(int teamMemberId) {
        TeamMemberId = teamMemberId;
    }

    public String getNatureOfInfraction() {
        return NatureOfInfraction;
    }

    public void setNatureOfInfraction(String natureOfInfraction) {
        NatureOfInfraction = natureOfInfraction;
    }

    public String getExplanation() {
        return Explanation;
    }

    public void setExplanation(String explanation) {
        Explanation = explanation;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

}
