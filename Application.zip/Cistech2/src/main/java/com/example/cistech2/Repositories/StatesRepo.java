package com.example.cistech2.Repositories;

import com.example.cistech2.Models.StatesEntity;
import org.springframework.data.repository.CrudRepository;

public interface StatesRepo extends CrudRepository<StatesEntity, Integer> {
}
