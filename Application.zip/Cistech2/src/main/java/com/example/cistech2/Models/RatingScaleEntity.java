package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "ratingscale")
public class RatingScaleEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "rating_id")
    private int RatingId;
    @Column(name = "rating")
    private int Rating;
    @Column(name = "description")
    private String Description;

    public RatingScaleEntity() {
    }

    public RatingScaleEntity(int rating, String description) {
        Rating = rating;
        Description = description;
    }

    public int getRatingId() {
        return RatingId;
    }

    public void setRatingId(int ratingId) {
        RatingId = ratingId;
    }

    public int getRating() {
        return Rating;
    }

    public void setRating(int rating) {
        Rating = rating;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

}
