package com.example.cistech2.Models;
import jdk.jshell.Snippet;

import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "referralstatus")
public class ReferralStatusEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "status_id")
    private int StatusId;
    @Column(name = "status")
    private String Status;


    public ReferralStatusEntity() {
    }

    public ReferralStatusEntity(String status) {
        Status = status;
    }

    public int getStatusId() {
        return StatusId;
    }

    public void setStatusId(int StatusId) {
        StatusId = this.StatusId;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

}
