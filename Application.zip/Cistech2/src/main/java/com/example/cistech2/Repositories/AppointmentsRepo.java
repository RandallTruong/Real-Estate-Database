package com.example.cistech2.Repositories;


import com.example.cistech2.Models.AppointmentsEntity;
import org.springframework.data.repository.CrudRepository;

public interface AppointmentsRepo extends CrudRepository<AppointmentsEntity, Integer> {

}