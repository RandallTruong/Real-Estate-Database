package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "amenities")
public class AmenitiesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "amenity_id")
    private int AmenityId;
    @Column(name = "amenity")
    private String Amenity;

    public AmenitiesEntity(){

    }

    public AmenitiesEntity( String amenity) {
        Amenity = amenity;
    }

    public int getAmenityId() {
        return AmenityId;
    }

    public void setAmenityId(int amenityId) {
        AmenityId = amenityId;
    }

    public String getAmenity() {
        return Amenity;
    }

    public void setAmenity(String amenity) {
        Amenity = amenity;
    }


}
