package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "listingfeatures")
public class ListingFeaturesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "listing_feature_id")
    private int ListingFeatureId;
    @Column(name = "lease_listing_id")
    private int LeaseListingId;
    @Column(name = "feature_id")
    private int FeatureId;

    public ListingFeaturesEntity() {
    }

    public ListingFeaturesEntity(int leaseListingId, int featureId) {
        LeaseListingId = leaseListingId;
        FeatureId = featureId;
    }

    public int getListingFeatureId() {
        return ListingFeatureId;
    }

    public void setListingFeatureId(int listingFeatureId) {
        ListingFeatureId = listingFeatureId;
    }

    public int getLeaseListingId() {
        return LeaseListingId;
    }

    public void setLeaseListingId(int leaseListingId) {
        LeaseListingId = leaseListingId;
    }

    public int getFeatureId() {
        return FeatureId;
    }

    public void setFeatureId(int featureId) {
        FeatureId = featureId;
    }

}
