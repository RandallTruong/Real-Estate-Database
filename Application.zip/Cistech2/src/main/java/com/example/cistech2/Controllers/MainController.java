package com.example.cistech2.Controllers;

import com.example.cistech2.Models.*;
import com.example.cistech2.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.rmi.dgc.Lease;
import java.util.Optional;

@Controller
public class MainController {

    @RequestMapping("/")
    public ModelAndView HomePage() {
        ModelAndView modelAndView = new ModelAndView("homepage");
        return modelAndView;
    }

    @Autowired
    StatesRepo StatesRepo;
    @RequestMapping("/states")
    public ModelAndView StatesPage(){
        ModelAndView modelAndView = new ModelAndView("states");
        modelAndView.addObject("stateslist", StatesRepo.findAll());
        return modelAndView;
    }

    @Autowired
    ZipcodesRepo ZipcodesRepo;
    @RequestMapping("/zipcodes")
    public ModelAndView ZipcodesPage(){
        ModelAndView modelAndView = new ModelAndView("zipcodes");
        modelAndView.addObject("zipcodeslist", ZipcodesRepo.findAll());
        return modelAndView;
    }

    @Autowired
   CountriesRepo CountriesRepo;
    @RequestMapping("/countries")
    public ModelAndView CountriesPage(){
        ModelAndView modelAndView = new ModelAndView("countries");
        modelAndView.addObject("countrieslist", CountriesRepo.findAll());
        return modelAndView;
    }

    @Autowired
    NanandcompanypropertiesRepo NanAndCompanyPropertiesRepo;
    @RequestMapping("/nanandcompanyproperties")
    public ModelAndView CompanyPage() {
        ModelAndView modelAndView = new ModelAndView("nanandcompanyproperties");
        modelAndView.addObject("nanandcompanypropertieslist", NanAndCompanyPropertiesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/nanandcompanyproperties/save", method = RequestMethod.POST)
    public ModelAndView save(
            @RequestParam("CompanyId") String CompanyId,
            @RequestParam("Administration") String Administration,
            @RequestParam("Address") String Address,
            @RequestParam("City") String City,
            @RequestParam("State") int State,
            @RequestParam("Zipcode") int Zipcode,
            @RequestParam("Country") int  Country,
            @RequestParam("Phone Number") String PhoneNumber,
            @RequestParam("Email") String Email
                             ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/nanandcompanyproperties");
        NanandcompanypropertiesEntity companyToSave;
        if(!CompanyId.isEmpty())
        {
            Optional<NanandcompanypropertiesEntity> Company = NanAndCompanyPropertiesRepo.findById(Integer.parseInt(CompanyId));
            companyToSave = Company.get();
        }
        else {
            companyToSave = new NanandcompanypropertiesEntity();
        }
        companyToSave.setAdministration(Administration);
        companyToSave.setAddress(Address);
        companyToSave.setCity(City);
        companyToSave.setStateId(State);
        companyToSave.setZipcodeId(Zipcode);
        companyToSave.setCountryId(Country);
        companyToSave.setPhoneNumber(PhoneNumber);
        companyToSave.setEmail(Email);
        NanAndCompanyPropertiesRepo.save(companyToSave);
        modelAndView.addObject("nanandcompanypropertieslist", NanAndCompanyPropertiesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "nanandcompanyproperties/edit/{id}", method = RequestMethod.GET)
    public ModelAndView edit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("nacpropertiesedit");
        Optional<NanandcompanypropertiesEntity> Nanandcompanyproperties = NanAndCompanyPropertiesRepo.findById(id);
       NanandcompanypropertiesEntity company = Nanandcompanyproperties.get();
        mv.addObject("selectedItem", company);
        return mv;
    }
    @RequestMapping(value = "nanandcompanyproperties/delete/{id}", method = RequestMethod.GET)
    public ModelAndView delete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/nanandcompanyproperties");
        NanAndCompanyPropertiesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    EmployeeInformationRepo EmployeeInformationRepo;
    @RequestMapping("/employeeinformation")
    public ModelAndView EmployeeInformationPage(){
        ModelAndView modelAndView = new ModelAndView("employeeinformation");
        modelAndView.addObject("employeeinformationlist", EmployeeInformationRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/employeeinformation/save", method = RequestMethod.POST)
    public ModelAndView employeesave(
            @RequestParam("EmployeeInformationId") String EmployeeId,
            @RequestParam("CompanyId") int employeeCompanyId,
            @RequestParam("FirstName") String employeeFirstName,
            @RequestParam("LastName") String employeeLastName,
            @RequestParam("Address") String employeeAddress,
            @RequestParam("City") String employeeCity,
            @RequestParam("StateId") int employeeStateId,
            @RequestParam("ZipcodeId") int employeeZipcodeId,
            @RequestParam("CountryId") int employeeCountryId,
            @RequestParam("PhoneNumber") String employeePhoneNumber,
            @RequestParam("Email") String employeeEmail
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/employeeinformation");
        EmployeeInformationEntity employeeToSave;
        if(!EmployeeId.isEmpty())
        {
            Optional<EmployeeInformationEntity> EmployeeInfo =
                    EmployeeInformationRepo.findById(Integer.parseInt(EmployeeId));
            employeeToSave = EmployeeInfo.get();
        }
        else {
            employeeToSave = new EmployeeInformationEntity();
        }
        employeeToSave.setCompanyId(employeeCompanyId);
        employeeToSave.setFirstName(employeeFirstName);
        employeeToSave.setLastName(employeeLastName);
        employeeToSave.setAddress(employeeAddress);
        employeeToSave.setCity(employeeCity);
        employeeToSave.setStateId(employeeStateId);
        employeeToSave.setZipcodeId(employeeZipcodeId);
        employeeToSave.setCountryId(employeeCountryId);
        employeeToSave.setPhoneNumber(employeePhoneNumber);
        employeeToSave.setEmail(employeeEmail);
        EmployeeInformationRepo.save(employeeToSave);
        modelAndView.addObject("employeeinformationlist", EmployeeInformationRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "employeeinformation/edit/{id}", method = RequestMethod.GET)
    public ModelAndView employeeedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("employeeinformationedit");
        Optional<EmployeeInformationEntity> employeeinformation = EmployeeInformationRepo.findById(id);
        EmployeeInformationEntity employee = employeeinformation.get();
        mv.addObject("selectedItem", employee);
        return mv;
    }
    @RequestMapping(value = "employeeinformation/delete/{id}", method = RequestMethod.GET)
    public ModelAndView employeedelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/employeeinformation");
        EmployeeInformationRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ProgramsRepo ProgramsRepo;
    @RequestMapping("/programs")
    public ModelAndView ProgramsPage(){
        ModelAndView modelAndView = new ModelAndView("programs");
        modelAndView.addObject("programslist", ProgramsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/programs/save", method = RequestMethod.POST)
    public ModelAndView programsave(
            @RequestParam("ProgramId") String programId,
            @RequestParam("CompanyId") int programCompanyId,
            @RequestParam("Title") String programTitle
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/programs");
        ProgramsEntity programToSave;
        if(!programId.isEmpty())
        {
            Optional<ProgramsEntity> Program = ProgramsRepo.findById(Integer.parseInt(programId));
            programToSave = Program.get();
        }
        else {
            programToSave =  new ProgramsEntity();
        }
        programToSave.setCompanyId(programCompanyId);
        programToSave.setTitle(programTitle);
        ProgramsRepo.save(programToSave);
        modelAndView.addObject("programslist", ProgramsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "programs/edit/{id}", method = RequestMethod.GET)
    public ModelAndView programsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("programsedit");
        Optional<ProgramsEntity> Program = ProgramsRepo.findById(id);
        ProgramsEntity program = Program.get();
        mv.addObject("selectedItem", program);
        return mv;
    }
    @RequestMapping(value = "programs/delete/{id}", method = RequestMethod.GET)
    public ModelAndView programsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/programs");
        ProgramsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ClientsRepo ClientsRepo;
    @RequestMapping("/clients")
    public ModelAndView ClientsPage(){
        ModelAndView modelAndView = new ModelAndView("clients");
        modelAndView.addObject("clientslist", ClientsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/clients/save", method = RequestMethod.POST)
    public ModelAndView clientsave(
                                      @RequestParam("ClientId") String ClientId,
                                      @RequestParam("CompanyId") int CompanyId,
                                      @RequestParam("AgentId") int clientAgentId,
                                      @RequestParam("FirstName") String clientFirstName,
                                      @RequestParam("LastName") String clientLastName,
                                      @RequestParam("Address") String clientAddress,
                                      @RequestParam("City") String clientCity,
                                      @RequestParam("StateId") int clientStateId,
                                      @RequestParam("ZipcodeId") int clientZipcodeId,
                                      @RequestParam("CountryId") int clientCountryId,
                                      @RequestParam("PhoneNumber") String clientPhoneNumber,
                                      @RequestParam("Email") String clientEmail
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/clients");
        ClientsEntity clientToSave;
        if(!ClientId.isEmpty())
        {
            Optional<ClientsEntity> Client =
                    ClientsRepo.findById(Integer.parseInt(ClientId));
            clientToSave = Client.get();
        }
        else {
            clientToSave = new ClientsEntity();
        }
        clientToSave.setCompanyId(CompanyId);
        clientToSave.setAgentId(clientAgentId);
        clientToSave.setFirstName(clientFirstName);
        clientToSave.setLastName(clientLastName);
        clientToSave.setAddress(clientAddress);
        clientToSave.setCity(clientCity);
        clientToSave.setStateId(clientStateId);
        clientToSave.setZipcodeId(clientZipcodeId);
        clientToSave.setCountryId(clientCountryId);
        clientToSave.setPhoneNumber(clientPhoneNumber);
        clientToSave.setEmail(clientEmail);
        ClientsRepo.save(clientToSave);
        modelAndView.addObject("clientslist", ClientsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "clients/edit/{id}", method = RequestMethod.GET)
    public ModelAndView clientsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("clientsedit");
        Optional<ClientsEntity> Clients = ClientsRepo.findById(id);
        ClientsEntity clients = Clients.get();
        mv.addObject("selectedItem", clients);
        return mv;
    }
    @RequestMapping(value = "clients/delete/{id}", method = RequestMethod.GET)
    public ModelAndView clientsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/clients");
        ClientsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ListingInformationRepo ListingInformationRepo;
    @RequestMapping("/listinginformation")
    public ModelAndView ListingInformationPage(){
        ModelAndView modelAndView = new ModelAndView("listinginformation");
        modelAndView.addObject("listinginformationlist", ListingInformationRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/ListingInformation/save", method = RequestMethod.POST)
    public ModelAndView listinginformationsave(
            @RequestParam("ListingId") String ListingId,
            @RequestParam("ClientId") int listingInformationClientId,
            @RequestParam("PropertyId") int listingInformationPropertyId,
            @RequestParam("Address") String listingInformationAddress,
            @RequestParam("City") String listingInformationCity,
            @RequestParam("StateId") int listingInformationStateId,
            @RequestParam("ZipcodeId") int listingInformationZipcodeId,
            @RequestParam("CountryId") int listingInformationCountryId,
            @RequestParam("SQFeet") int sqFeet,
            @RequestParam("Number of Bedrooms") int bedrooms,
            @RequestParam("Number of Bathrooms") int bathrooms
    ) { ModelAndView modelAndView = new ModelAndView("redirect:/listinginformation");
        ListingInformationEntity listingInformationToSave;
        if(!ListingId.isEmpty())
        {
            Optional<ListingInformationEntity> Listinginfo =
                    ListingInformationRepo.findById(Integer.parseInt(ListingId));
            listingInformationToSave = Listinginfo.get();
        }
        else {
            listingInformationToSave = new ListingInformationEntity();
        }
        listingInformationToSave.setClientId(listingInformationClientId);
        listingInformationToSave.setPropertyId(listingInformationPropertyId);
        listingInformationToSave.setAddress(listingInformationAddress);
        listingInformationToSave.setCity(listingInformationCity);
        listingInformationToSave.setStateId(listingInformationStateId);
        listingInformationToSave.setZipcodeId(listingInformationZipcodeId);
        listingInformationToSave.setCountryId(listingInformationCountryId);
        listingInformationToSave.setSQFeet(sqFeet);
        listingInformationToSave.setNumberOfBedrooms(bedrooms);
        listingInformationToSave.setNumberOfBathrooms(bathrooms);
        ListingInformationRepo.save(listingInformationToSave);
        modelAndView.addObject("listinginformationlist", ListingInformationRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "ListingInformation/edit/{id}", method = RequestMethod.GET)
    public ModelAndView listinginformationedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("listinginformationedit");
        Optional<ListingInformationEntity> ListingInformation = ListingInformationRepo.findById(id);
        ListingInformationEntity listing = ListingInformation.get();
        mv.addObject("selectedItem", listing);
        return mv;
    }
    @RequestMapping(value = "ListingInformation/delete/{id}", method = RequestMethod.GET)
    public ModelAndView listinginformationdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/listinginformation");
        ListingInformationRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    AgentsRepo AgentsRepo;
    @RequestMapping("/agents")
    public ModelAndView AgentsPage(){
        ModelAndView modelAndView = new ModelAndView("agents");
        modelAndView.addObject("agentslist", AgentsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/agents/save", method = RequestMethod.POST)
    public ModelAndView agentsave(
            @RequestParam("AgentId") String AgentId,
            @RequestParam("TeamMemberId") int TeamMemberId,
            @RequestParam("CertificateId") int CertificateId,
            @RequestParam("TrecLicense#") String TrecLicense,
            @RequestParam("RankId") int RankId,
            @RequestParam("Date") String Date
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/agents");
        AgentsEntity agentToSave;
        if(!AgentId.isEmpty())
        {
            Optional<AgentsEntity> agent =
                    AgentsRepo.findById(Integer.parseInt(AgentId));
            agentToSave = agent.get();
        }
        else {
            agentToSave = new AgentsEntity();
        }

        agentToSave.setTeamMemberId(TeamMemberId);
        agentToSave.setCertificateId(CertificateId);
        agentToSave.setTrecLicense(TrecLicense);
        agentToSave.setRankId(RankId);
        agentToSave.setDate(Date);
        AgentsRepo.save(agentToSave);
        modelAndView.addObject("agentslist", AgentsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "agents/edit/{id}", method = RequestMethod.GET)
    public ModelAndView agentsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("agentsedit");
        Optional<AgentsEntity> Agent = AgentsRepo.findById(id);
        AgentsEntity agent = Agent.get();
        mv.addObject("selectedItem", agent);
        return mv;
    }
    @RequestMapping(value = "agents/delete/{id}", method = RequestMethod.GET)
    public ModelAndView agentsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/agents");
        AgentsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ComplaintsRepo ComplaintsRepo;
    @RequestMapping("/complaints")
    public ModelAndView ComplaintsPage(){
        ModelAndView modelAndView = new ModelAndView("complaints");
        modelAndView.addObject("complaintslist", ComplaintsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/complaints/save", method = RequestMethod.POST)
    public ModelAndView complaintsave(
            @RequestParam("ComplaintId") String ComplaintId,
            @RequestParam("CompanyId") int complaintCompanyId,
            @RequestParam("NatureofComplaint") String natureOfComplaint,
            @RequestParam("Description") String complaintDescription,
            @RequestParam("Date") String complaintDate
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/complaints");
        ComplaintsEntity complaintToSave;
        if(!ComplaintId.isEmpty())
        {
            Optional<ComplaintsEntity> complaint =
                    ComplaintsRepo.findById(Integer.parseInt(ComplaintId));
            complaintToSave = complaint.get();
        }
        else {
            complaintToSave = new ComplaintsEntity();
        }
        complaintToSave.setCompanyId(complaintCompanyId);
        complaintToSave.setNatureOfComplaint(natureOfComplaint);
        complaintToSave.setDescription(complaintDescription);
        complaintToSave.setDate(complaintDate);
        ComplaintsRepo.save(complaintToSave);
        modelAndView.addObject("complaintslist", ComplaintsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "complaints/edit/{id}", method = RequestMethod.GET)
    public ModelAndView complaintsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("complaintsedit");
        Optional<ComplaintsEntity> Complaint = ComplaintsRepo.findById(id);
        ComplaintsEntity complaint = Complaint.get();
        mv.addObject("selectedItem", complaint);
        return mv;
    }
    @RequestMapping(value = "complaints/delete/{id}", method = RequestMethod.GET)
    public ModelAndView complaintsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/complaints");
        ComplaintsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    CompanyLeadsRepo CompanyLeadsRepo;
    @RequestMapping("/companyleads")
    public ModelAndView CompanyLeadsPage(){
        ModelAndView modelAndView = new ModelAndView("companyleads");
        modelAndView.addObject("companyleadslist", CompanyLeadsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/companyleads/save", method = RequestMethod.POST)
    public ModelAndView companyleadsave(
                                      @RequestParam("CompanyLeadId") String CompanyLeadId,
                                      @RequestParam("CompanyId") int CompanyId,
                                      @RequestParam("FirstName") String companyLeadFirstName,
                                      @RequestParam("LastName") String companyLeadLastName,
                                      @RequestParam("PhoneNumber") String companyLeadPhoneNumber,
                                      @RequestParam("Email") String companyLeadEmail
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/companyleads");
        CompanyLeadsEntity companyLeadToSave;
        if(!CompanyLeadId.isEmpty())
        {
            Optional<CompanyLeadsEntity> companylead =
                    CompanyLeadsRepo.findById(Integer.parseInt(CompanyLeadId));
            companyLeadToSave = companylead.get();
        }
        else {
            companyLeadToSave = new CompanyLeadsEntity();
        }
        companyLeadToSave.setCompanyId(CompanyId);
        companyLeadToSave.setFirstName(companyLeadFirstName);
        companyLeadToSave.setLastName(companyLeadLastName);
        companyLeadToSave.setPhoneNumber(companyLeadPhoneNumber);
        companyLeadToSave.setEmail(companyLeadEmail);
        CompanyLeadsRepo.save(companyLeadToSave);
        modelAndView.addObject("companyleadslist", CompanyLeadsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "companyleads/edit/{id}", method = RequestMethod.GET)
    public ModelAndView companyleadsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("companyleadsedit");
        Optional<CompanyLeadsEntity> CompanyLeads = CompanyLeadsRepo.findById(id);
        CompanyLeadsEntity companylead = CompanyLeads.get();
        mv.addObject("selectedItem", companylead);
        return mv;
    }
    @RequestMapping(value = "companyleads/delete/{id}", method = RequestMethod.GET)
    public ModelAndView companyleadsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/companyleads");
        CompanyLeadsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    TerminatedAgentsRepo TerminatedAgentsRepo;
    @RequestMapping("/terminatedagents")
    public ModelAndView TerminatedAgentsPage(){
        ModelAndView modelAndView = new ModelAndView("terminatedagents");
        modelAndView.addObject("terminatedagentslist", TerminatedAgentsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/terminatedagents/save", method = RequestMethod.POST)
    public ModelAndView terminatedagentssave(
            @RequestParam("TerminationId") String TerminationId,
            @RequestParam("CompanyId") int CompanyId,
            @RequestParam("FirstName") String FirstName,
            @RequestParam("LastName") String LastName,
            @RequestParam("TerminationDate") String TerminationDate,
            @RequestParam("Explanation") String Explanation
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/terminatedagents");
        TerminatedAgentsEntity terminatedAgentToSave;
        if(!TerminationId.isEmpty())
        {
            Optional<TerminatedAgentsEntity> termination =
                    TerminatedAgentsRepo.findById(Integer.parseInt(TerminationId));
            terminatedAgentToSave = termination.get();
        }
        else {
            terminatedAgentToSave = new TerminatedAgentsEntity();
        }
        terminatedAgentToSave.setCompanyId(CompanyId);
        terminatedAgentToSave.setFirstName(FirstName);
        terminatedAgentToSave.setLastName(LastName);
        terminatedAgentToSave.setTerminationDate(TerminationDate);
        terminatedAgentToSave.setExplanation(Explanation);
        TerminatedAgentsRepo.save(terminatedAgentToSave);
        modelAndView.addObject("terminatedagentslist", TerminatedAgentsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "terminatedagents/edit/{id}", method = RequestMethod.GET)
    public ModelAndView terminatedagentsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("terminatedagentsedit");
        Optional<TerminatedAgentsEntity> Terminated = TerminatedAgentsRepo.findById(id);
        TerminatedAgentsEntity terminated = Terminated.get();
        mv.addObject("selectedItem", terminated);
        return mv;
    }
    @RequestMapping(value = "terminatedagents/delete/{id}", method = RequestMethod.GET)
    public ModelAndView terminatedagentsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/terminatedagents");
       TerminatedAgentsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    SocialMediaRepo SocialMediaRepo;
    @RequestMapping("/socialmedia")
    public ModelAndView SocialMediaPage(){
        ModelAndView modelAndView = new ModelAndView("socialmedia");
        modelAndView.addObject("socialmedialist", SocialMediaRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/socialmedia/save", method = RequestMethod.POST)
    public ModelAndView socialmediasave(
            @RequestParam("SocialMediaId") String SocialMediaId,
            @RequestParam("CompanyId") int socialMediaCompanyId,
            @RequestParam("Platform") String Platform,
            @RequestParam("AccountName") String AccountName

    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/socialmedia");
        SocialMediaEntity socialMediaToSave;
        if(!SocialMediaId.isEmpty())
        {
            Optional<SocialMediaEntity> socialmedia =
                    SocialMediaRepo.findById(Integer.parseInt(SocialMediaId));
            socialMediaToSave = socialmedia.get();
        }
        else {
            socialMediaToSave = new SocialMediaEntity();
        }
        socialMediaToSave.setCompanyId(socialMediaCompanyId);
        socialMediaToSave.setPlatform(Platform);
        socialMediaToSave.setAccountName(AccountName);
        SocialMediaRepo.save(socialMediaToSave);
        modelAndView.addObject("socialmedialist", SocialMediaRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "socialmedia/edit/{id}", method = RequestMethod.GET)
    public ModelAndView socialmediaedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("socialmediaedit");
        Optional<SocialMediaEntity> SocialMedia = SocialMediaRepo.findById(id);
        SocialMediaEntity socialmedia = SocialMedia.get();
        mv.addObject("selectedItem", socialmedia);
        return mv;
    }
    @RequestMapping(value = "socialmedia/delete/{id}", method = RequestMethod.GET)
    public ModelAndView socialmediadelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/socialmedia");
        SocialMediaRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    BootcampsRepo BootcampsRepo;
    @RequestMapping("/bootcamps")
    public ModelAndView BootcampsPage(){
        ModelAndView modelAndView = new ModelAndView("bootcamps");
        modelAndView.addObject("bootcampslist", BootcampsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/bootcamps/save", method = RequestMethod.POST)
    public ModelAndView bootcampssave(
            @RequestParam("BootcampId") String BootcampId,
            @RequestParam("ProgramId") int BootcampProgramId,
            @RequestParam("Title") String Title
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/bootcamps");
        BootcampsEntity bootcampToSave;
        if(!BootcampId.isEmpty())
        {
            Optional<BootcampsEntity> bootcamp =
                    BootcampsRepo.findById(Integer.parseInt(BootcampId));
            bootcampToSave = bootcamp.get();
        }
        else {
            bootcampToSave = new BootcampsEntity();
        }
        bootcampToSave.setProgramId(BootcampProgramId);
        bootcampToSave.setTitle(Title);
        BootcampsRepo.save(bootcampToSave);
        modelAndView.addObject("bootcampslist", BootcampsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "bootcamps/edit/{id}", method = RequestMethod.GET)
    public ModelAndView bootcampsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("bootcampsedit");
        Optional<BootcampsEntity> Bootcamp = BootcampsRepo.findById(id);
        BootcampsEntity bootcamp = Bootcamp.get();
        mv.addObject("selectedItem", bootcamp);
        return mv;
    }
    @RequestMapping(value = "bootcamps/delete/{id}", method = RequestMethod.GET)
    public ModelAndView bootcampsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/bootcamps");
        BootcampsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    EnrollProgramsRepo EnrollProgramsRepo;
    @RequestMapping("/enrollprograms")
    public ModelAndView EnrollProgramsPage(){
        ModelAndView modelAndView = new ModelAndView("enrollprograms");
        modelAndView.addObject("enrollprogramslist", EnrollProgramsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/enrollprograms/save", method = RequestMethod.POST)
    public ModelAndView enrollmentsave(
            @RequestParam("EnrollProgramId") String EnrollProgramId,
            @RequestParam("ProgramId") int enrollmentProgramId,
            @RequestParam("EmployeeId") int enrollmentEmployeeId,
            @RequestParam("Date") String enrollmentDate
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/enrollprograms");
        EnrollProgramsEntity enrollProgramToSave;
        if(!EnrollProgramId.isEmpty())
        {
            Optional<EnrollProgramsEntity> enrollprogram =
                    EnrollProgramsRepo.findById(Integer.parseInt(EnrollProgramId));
            enrollProgramToSave = enrollprogram.get();
        }
        else {
            enrollProgramToSave = new EnrollProgramsEntity();
        }
        enrollProgramToSave.setProgramId(enrollmentProgramId);
        enrollProgramToSave.setEmployeeId(enrollmentEmployeeId);
        enrollProgramToSave.setDate(enrollmentDate);
        EnrollProgramsRepo.save(enrollProgramToSave);
        modelAndView.addObject("enrollprogramslist", EnrollProgramsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "enrollprograms/edit/{id}", method = RequestMethod.GET)
    public ModelAndView enrollprogramsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("enrollprogramsedit");
        Optional<EnrollProgramsEntity> EnrollProgram = EnrollProgramsRepo.findById(id);
        EnrollProgramsEntity enrollprogram = EnrollProgram.get();
        mv.addObject("selectedItem", enrollprogram);
        return mv;
    }
    @RequestMapping(value = "enrollprograms/delete/{id}", method = RequestMethod.GET)
    public ModelAndView enrollprogramsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/enrollprograms");
        EnrollProgramsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    EquipmentRepo EquipmentRepo;
    @RequestMapping("/equipment")
    public ModelAndView EquipmentPage(){
        ModelAndView modelAndView = new ModelAndView("equipment");
        modelAndView.addObject("equipmentlist", EquipmentRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/equipment/save", method = RequestMethod.POST)
    public ModelAndView equipmentsave( @RequestParam("EquipmentId") String EquipmentId,
                                       @RequestParam("BootcampId") int equipmentBootcampId,
                                       @RequestParam("Equipment") String Equipment,
                                       @RequestParam("Value") float equipmentValue,
                                       @RequestParam("Quantity") int equipmentQuantity
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/equipment");
        EquipmentEntity equipmentToSave;
        if(!EquipmentId.isEmpty())
        {
            Optional<EquipmentEntity> equipment =
                    EquipmentRepo.findById(Integer.parseInt(EquipmentId));
            equipmentToSave = equipment.get();
        }
        else {
            equipmentToSave = new EquipmentEntity();
        }
        equipmentToSave.setBootcampId(equipmentBootcampId);
        equipmentToSave.setEquipment(Equipment);
        equipmentToSave.setValue(equipmentValue);
        equipmentToSave.setQuantity(equipmentQuantity);
        EquipmentRepo.save(equipmentToSave);
        modelAndView.addObject("equipmentlist", EquipmentRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "equipment/edit/{id}", method = RequestMethod.GET)
    public ModelAndView equipmentedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("equipmentedit");
        Optional<EquipmentEntity> Equipment = EquipmentRepo.findById(id);
        EquipmentEntity equipment = Equipment.get();
        mv.addObject("selectedItem", equipment);
        return mv;
    }
    @RequestMapping(value = "equipment/delete/{id}", method = RequestMethod.GET)
    public ModelAndView equipmentdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/equipment");
        EquipmentRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    CoursesRepo CoursesRepo;
    @RequestMapping("/courses")
    public ModelAndView CoursesPage(){
        ModelAndView modelAndView = new ModelAndView("courses");
        modelAndView.addObject("courseslist", CoursesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/courses/save", method = RequestMethod.POST)
    public ModelAndView coursesave(
            @RequestParam("CourseId") String CourseId,
            @RequestParam("BootcampId") int courseBootcampId,
            @RequestParam("Title") String coursesTitle
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/courses");
        CoursesEntity courseToSave;
        if(!CourseId.isEmpty())
        {
            Optional<CoursesEntity> course =
                    CoursesRepo.findById(Integer.parseInt(CourseId));
            courseToSave = course.get();
        }
        else {
            courseToSave = new CoursesEntity();
        }
        courseToSave.setBootcampId(courseBootcampId);
        courseToSave.setTitle(coursesTitle);
        CoursesRepo.save(courseToSave);
        modelAndView.addObject("courseslist", CoursesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "courses/edit/{id}", method = RequestMethod.GET)
    public ModelAndView coursesedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("coursesedit");
        Optional<CoursesEntity> Course = CoursesRepo.findById(id);
        CoursesEntity course = Course.get();
        mv.addObject("selectedItem", course);
        return mv;
    }
    @RequestMapping(value = "courses/delete/{id}", method = RequestMethod.GET)
    public ModelAndView coursesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/courses");
        CoursesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    GradesRepo GradesRepo;
    @RequestMapping("/grades")
    public ModelAndView GradesPage(){
        ModelAndView modelAndView = new ModelAndView("grades");
        modelAndView.addObject("gradeslist", GradesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/grades/save", method = RequestMethod.POST)

    public ModelAndView gradesave(
            @RequestParam("GradeId") String GradeId,
            @RequestParam("BootcampId") int gradeBootcampId,
            @RequestParam("EmployeeId") int gradeEmployeeId,
            @RequestParam("Grade") String Grade
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/grades");
        GradesEntity gradeToSave;
        if(!GradeId.isEmpty())
        {
            Optional<GradesEntity> grade =
                    GradesRepo.findById(Integer.parseInt(GradeId));
            gradeToSave = grade.get();
        }
        else {
            gradeToSave = new GradesEntity();
        }
        gradeToSave.setBootcampId(gradeBootcampId);
        gradeToSave.setEmployeeId(gradeEmployeeId);
        gradeToSave.setGrade(Grade);
        GradesRepo.save(gradeToSave);
        modelAndView.addObject("gradeslist", GradesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "grades/edit/{id}", method = RequestMethod.GET)
    public ModelAndView gradesedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("gradesedit");
        Optional<GradesEntity> Grade = GradesRepo.findById(id);
        GradesEntity grade = Grade.get();
        mv.addObject("selectedItem", grade);
        return mv;
    }
    @RequestMapping(value = "grades/delete/{id}", method = RequestMethod.GET)
    public ModelAndView gradesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/grades");
        GradesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    InstructorsRepo InstructorsRepo;
    @RequestMapping("/instructors")
    public ModelAndView InstructorsPage(){
        ModelAndView modelAndView = new ModelAndView("instructors");
        modelAndView.addObject("instructorslist", InstructorsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/instructors/save", method = RequestMethod.POST)
    public ModelAndView instructorsave( @RequestParam("InstructorId") String InstructorId,
                                        @RequestParam("CourseId") int instructorCourseId,
                                        @RequestParam("FirstName") String instructorFirstName,
                                        @RequestParam("LastName") String instructorLastName,
                                        @RequestParam("PhoneNumber") String instructorPhoneNumber,
                                        @RequestParam("Email") String instructorEmail,
                                        @RequestParam("Qualification") String qualification
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/instructors");
        InstructorsEntity instructorToSave;
        if(!InstructorId.isEmpty())
        {
            Optional<InstructorsEntity> instructor =
                    InstructorsRepo.findById(Integer.parseInt(InstructorId));
            instructorToSave = instructor.get();
        }
        else {
            instructorToSave = new InstructorsEntity();
        }
       instructorToSave.setCourseId(instructorCourseId);
       instructorToSave.setFirstName(instructorFirstName);
       instructorToSave.setLastName(instructorLastName);
       instructorToSave.setPhoneNumber(instructorPhoneNumber);
       instructorToSave.setEmail(instructorEmail);
       instructorToSave.setQualification(qualification);
       InstructorsRepo.save(instructorToSave);
        modelAndView.addObject("instructorslist", InstructorsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "instructors/edit/{id}", method = RequestMethod.GET)
    public ModelAndView instructorsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("instructorsedit");
        Optional<InstructorsEntity> Instructor = InstructorsRepo.findById(id);
        InstructorsEntity instructor = Instructor.get();
        mv.addObject("selectedItem", instructor);
        return mv;
    }
    @RequestMapping(value = "instructors/delete/{id}", method = RequestMethod.GET)
    public ModelAndView instructorsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/instructors");
        InstructorsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    FeedbacksRepo FeedbacksRepo;
    @RequestMapping("/feedbacks")
    public ModelAndView FeedbackPage(){
        ModelAndView modelAndView = new ModelAndView("feedbacks");
        modelAndView.addObject("feedbackslist", FeedbacksRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/feedbacks/save", method = RequestMethod.POST)
    public ModelAndView feedbacksave(
            @RequestParam("FeedbackId") String FeedbackId,
            @RequestParam("CourseId") int feedbackCourseId,
            @RequestParam("RatingId") int feedbackRatingId,
            @RequestParam("Date") String feedbackDate,
            @RequestParam("Comment") String feedbackComment
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/feedbacks");
        FeedbacksEntity feedbackToSave;
        if(!FeedbackId.isEmpty())
        {
            Optional<FeedbacksEntity> feedback =
                    FeedbacksRepo.findById(Integer.parseInt(FeedbackId));
            feedbackToSave = feedback.get();
        }
        else {
            feedbackToSave = new FeedbacksEntity();
        }
        feedbackToSave.setCourseId(feedbackCourseId);
        feedbackToSave.setRatingId(feedbackRatingId);
        feedbackToSave.setDate(feedbackDate);
        feedbackToSave.setComments(feedbackComment);
        FeedbacksRepo.save(feedbackToSave);
        modelAndView.addObject("feedbackslist", FeedbacksRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "feedbacks/edit/{id}", method = RequestMethod.GET)
    public ModelAndView feedbacksedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("feedbacksedit");
        Optional<FeedbacksEntity> Feedbacks = FeedbacksRepo.findById(id);
        FeedbacksEntity feedbacks = Feedbacks.get();
        mv.addObject("selectedItem", feedbacks);
        return mv;
    }
    @RequestMapping(value = "feedbacks/delete/{id}", method = RequestMethod.GET)
    public ModelAndView feedbacksdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/feedbacks");
        FeedbacksRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    RatingScaleRepo RatingScaleRepo;
    @RequestMapping("/ratingscale")
    public ModelAndView RatingScalePage(){
        ModelAndView modelAndView = new ModelAndView("ratingscale");
        modelAndView.addObject("ratingscalelist", RatingScaleRepo.findAll());
        return modelAndView;
    }


    @Autowired
    CertificatesRepo CertificatesRepo;
    @RequestMapping("/certificates")
    public ModelAndView CertificatesPage(){
        ModelAndView modelAndView = new ModelAndView("certificates");
        modelAndView.addObject("certificateslist", CertificatesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/certificates/save", method = RequestMethod.POST)
    public ModelAndView certificatesave(
            @RequestParam("CertificateId") String CertificateId,
            @RequestParam("GradeId") int CertificateGradeId,
            @RequestParam("Certification") String Certification
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/certificates");
        CertificatesEntity certificateToSave;
        if(!CertificateId.isEmpty())
        {
            Optional<CertificatesEntity> certificate =
                    CertificatesRepo.findById(Integer.parseInt(CertificateId));
            certificateToSave = certificate.get();
        }
        else {
            certificateToSave = new CertificatesEntity();
        }
        certificateToSave.setGradeId(CertificateGradeId);
        certificateToSave.setCertification(Certification);
        CertificatesRepo.save(certificateToSave);
        modelAndView.addObject("certificateslist", CertificatesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "certificates/edit/{id}", method = RequestMethod.GET)
    public ModelAndView certificatesedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("certificatesedit");
        Optional<CertificatesEntity> Certificate = CertificatesRepo.findById(id);
        CertificatesEntity certificate = Certificate.get();
        mv.addObject("selectedItem", certificate);
        return mv;
    }
    @RequestMapping(value = "certificates/delete/{id}", method = RequestMethod.GET)
    public ModelAndView certificatesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/certificates");
        CertificatesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    NonAgentRolesRepo NonAgentRolesRepo;
    @RequestMapping("/nonagentroles")
    public ModelAndView NonAgentRolesPage(){
        ModelAndView modelAndView = new ModelAndView("nonagentroles");
        modelAndView.addObject("nonagentroleslist", NonAgentRolesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/nonagentroles/save", method = RequestMethod.POST)
    public ModelAndView nonagentrolesave(
            @RequestParam("NonAgentRoleId") String NonAgentRoleId,
            @RequestParam("EmployeeId") int nonAgentRolesEmployeeId,
            @RequestParam("RoleTypeId") int nonAgentRolesRoleTypeId,
            @RequestParam("Date") String nonAgentRoleDate
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/nonagentroles");
        NonAgentRolesEntity nonAgentRoleToSave;
        if(!NonAgentRoleId.isEmpty())
        {
            Optional<NonAgentRolesEntity> nonagentrole =
                    NonAgentRolesRepo.findById(Integer.parseInt(NonAgentRoleId));
            nonAgentRoleToSave = nonagentrole.get();
        }
        else {
            nonAgentRoleToSave = new NonAgentRolesEntity();
        }
        nonAgentRoleToSave.setEmployeeId(nonAgentRolesEmployeeId);
        nonAgentRoleToSave.setRoleTypeId(nonAgentRolesRoleTypeId);
        nonAgentRoleToSave.setDate(nonAgentRoleDate);
        NonAgentRolesRepo.save(nonAgentRoleToSave);
        modelAndView.addObject("nonagentroleslist", NonAgentRolesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "nonagentroles/edit/{id}", method = RequestMethod.GET)
    public ModelAndView nonagentrolesedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("nonagentrolesedit");
        Optional<NonAgentRolesEntity> NonAgentRole = NonAgentRolesRepo.findById(id);
        NonAgentRolesEntity nonagentrole = NonAgentRole.get();
        mv.addObject("selectedItem", nonagentrole);
        return mv;
    }
    @RequestMapping(value = "nonagentroles/delete/{id}", method = RequestMethod.GET)
    public ModelAndView nonagentrolesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/nonagentroles");
        NonAgentRolesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    InfractionsRepo InfractionsRepo;
    @RequestMapping("/infractions")
    public ModelAndView InfractionsPage(){
        ModelAndView modelAndView = new ModelAndView("infractions");
        modelAndView.addObject("infractionslist", InfractionsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/infractions/save", method = RequestMethod.POST)
    public ModelAndView infractionsave(
            @RequestParam("InfractionId") String InfractionId,
            @RequestParam("TeamMemberId") int infractionTeamMemberId,
            @RequestParam("Nature") String infractionNature,
            @RequestParam("Explanation") String infractionExplanation,
            @RequestParam("Date") String infractionDate
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/infractions");
        InfractionsEntity infractionToSave;
        if(!InfractionId.isEmpty())
        {
            Optional<InfractionsEntity> infraction =
                    InfractionsRepo.findById(Integer.parseInt(InfractionId));
            infractionToSave = infraction.get();
        }
        else {
            infractionToSave = new InfractionsEntity();
        }
        infractionToSave.setTeamMemberId(infractionTeamMemberId);
        infractionToSave.setNatureOfInfraction(infractionNature);
        infractionToSave.setExplanation(infractionExplanation);
        infractionToSave.setDate(infractionDate);
        InfractionsRepo.save(infractionToSave);
        modelAndView.addObject("infractionslist", InfractionsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "infractions/edit/{id}", method = RequestMethod.GET)
    public ModelAndView infractionsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("infractionsedit");
        Optional<InfractionsEntity> Infraction = InfractionsRepo.findById(id);
        InfractionsEntity infraction = Infraction.get();
        mv.addObject("selectedItem", infraction);
        return mv;
    }
    @RequestMapping(value = "infractions/delete/{id}", method = RequestMethod.GET)
    public ModelAndView infractionsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/infractions");
        InfractionsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    RoleTypesRepo RoleTypesRepo;
    @RequestMapping("/roletypes")
    public ModelAndView RoleTypesPage(){
        ModelAndView modelAndView = new ModelAndView("roletypes");
        modelAndView.addObject("roletypeslist", RoleTypesRepo.findAll());
        return modelAndView;
    }


    @Autowired
    ProbationPeriodsRepo ProbationPeriodsRepo;
    @RequestMapping("/probationperiods")
    public ModelAndView ProbationPeriodsPage(){
        ModelAndView modelAndView = new ModelAndView("probationperiods");
        modelAndView.addObject("probationperiodslist", ProbationPeriodsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/probationperiods/save", method = RequestMethod.POST)
    public ModelAndView probationperiodsssave(
            @RequestParam("ProbationId") String probationId,
            @RequestParam("TeamMemberId") int teamMemberId,
            @RequestParam("ProbationStartDate") String probationStartDate,
            @RequestParam("ProbationEndDate") String probationEndDate,
            @RequestParam("NumberOfTransactions") int numberOfTransactions,
            @RequestParam("Notes") String notes
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/probationperiods");
        ProbationPeriodsEntity probationPeriodToSave;
        if(!probationId.isEmpty())
        {
            Optional<ProbationPeriodsEntity> ProbationPeriod =
                    ProbationPeriodsRepo.findById(Integer.parseInt(probationId));
            probationPeriodToSave= ProbationPeriod.get();
        }
        else {
            probationPeriodToSave = new ProbationPeriodsEntity();
        }
        probationPeriodToSave.setTeamMemberId(teamMemberId);
        probationPeriodToSave.setProbationStartDate(probationStartDate);
        probationPeriodToSave.setProbationEndDate(probationEndDate);
        probationPeriodToSave.setNumberOfTransactions(numberOfTransactions);
        probationPeriodToSave.setNotes(notes);
        ProbationPeriodsRepo.save(probationPeriodToSave);
        modelAndView.addObject("probationperiodslist", ProbationPeriodsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "probationperiods/edit/{id}", method = RequestMethod.GET)
    public ModelAndView probationperiodsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("probationperiodsedit");
        Optional<ProbationPeriodsEntity> ProbationPeriod = ProbationPeriodsRepo.findById(id);
        ProbationPeriodsEntity probationperiod = ProbationPeriod.get();
        mv.addObject("selectedItem", probationperiod);
        return mv;
    }
    @RequestMapping(value = "probationperiods/delete/{id}", method = RequestMethod.GET)
    public ModelAndView probationperiodsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/probationperiods");
        ProbationPeriodsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    AgentRanksRepo AgentRanksRepo;
    @RequestMapping("/agentranks")
    public ModelAndView AgentRanksPage(){
        ModelAndView modelAndView = new ModelAndView("agentranks");
        modelAndView.addObject("agentrankslist", AgentRanksRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/agentranks/save", method = RequestMethod.POST)
    public ModelAndView agentranksave(
            @RequestParam("AgentRankId") String AgentRankId,
            @RequestParam("Rank") String Rank,
            @RequestParam("Description") String Description
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/agentranks");
        AgentRanksEntity agentRanktoSave;
        if(!AgentRankId.isEmpty())
        {
            Optional<AgentRanksEntity> agentrank =
                    AgentRanksRepo.findById(Integer.parseInt(AgentRankId));
            agentRanktoSave = agentrank.get();
        }
        else {
            agentRanktoSave = new AgentRanksEntity();
        }
        agentRanktoSave.setRank(Rank);
        agentRanktoSave.setDescription(Description);
        AgentRanksRepo.save(agentRanktoSave);
        modelAndView.addObject("agentrankslist", AgentRanksRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "agentranks/edit/{id}", method = RequestMethod.GET)
    public ModelAndView agentranksedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("agentranksedit");
        Optional<AgentRanksEntity> AgentRank = AgentRanksRepo.findById(id);
        AgentRanksEntity agentrank = AgentRank.get();
        mv.addObject("selectedItem", agentrank);
        return mv;
    }
    @RequestMapping(value = "agentranks/delete/{id}", method = RequestMethod.GET)
    public ModelAndView agentranksdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/agentranks");
        AgentRanksRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    TestimonialsRepo TestimonialsRepo;
    @RequestMapping("/testimonials")
    public ModelAndView TestimonialsPage(){
        ModelAndView modelAndView = new ModelAndView("testimonials");
        modelAndView.addObject("testimonialslist", TestimonialsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/testimonials/save", method = RequestMethod.POST)
    public ModelAndView testimonialssave(
            @RequestParam("TestimonialId") String testimonialId,
            @RequestParam("AgentId") int agentId,
            @RequestParam("RatingId") int ratingId,
            @RequestParam("Comment") String comment,
            @RequestParam("Date") String date
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/testimonials");
        TestimonialsEntity testimonialToSave;
        if(!testimonialId.isEmpty())
        {
            Optional<TestimonialsEntity> testimonial =
                    TestimonialsRepo.findById(Integer.parseInt(testimonialId));
            testimonialToSave = testimonial.get();
        }
        else {
            testimonialToSave = new TestimonialsEntity();
        }
        testimonialToSave.setAgentId(agentId);
        testimonialToSave.setRatingId(ratingId);
        testimonialToSave.setComment(comment);
        testimonialToSave.setDate(date);
        TestimonialsRepo.save(testimonialToSave);
        modelAndView.addObject("testmimoniallist", TestimonialsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "testimonials/edit/{id}", method = RequestMethod.GET)
    public ModelAndView testimonialedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("testimonialsedit");
        Optional<TestimonialsEntity> Testimonial = TestimonialsRepo.findById(id);
        TestimonialsEntity testimonial = Testimonial.get();
        mv.addObject("selectedItem", testimonial);
        return mv;
    }
    @RequestMapping(value = "testimonials/delete/{id}", method = RequestMethod.GET)
    public ModelAndView testimonialdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/testimonials");
        TestimonialsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    AgentLeadsRepo AgentLeadsRepo;
    @RequestMapping("/agentleads")
    public ModelAndView AgentLeadsPage(){
        ModelAndView modelAndView = new ModelAndView("agentleads");
        modelAndView.addObject("agentleadslist", AgentLeadsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/agentleads/save", method = RequestMethod.POST)
    public ModelAndView save(
            @RequestParam("AgentLeadId") String AgentLeadId,
            @RequestParam("AgentId") int AgentId,
            @RequestParam("FirstName") String FirstName,
            @RequestParam("LastName") String LastName,
            @RequestParam("PhoneNumber") String PhoneNumber,
            @RequestParam("Email") String Email,
            @RequestParam("SplitPercentage") String SplitPercentage
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/agentleads");
        AgentLeadsEntity agentLeadtoSave;
        if(!AgentLeadId.isEmpty())
        {
            Optional<AgentLeadsEntity> agentlead =
                    AgentLeadsRepo.findById(Integer.parseInt(AgentLeadId));
            agentLeadtoSave = agentlead.get();
        }
        else {
            agentLeadtoSave = new AgentLeadsEntity();
        }
        agentLeadtoSave.setAgentId(AgentId);
        agentLeadtoSave.setFirstName(FirstName);
        agentLeadtoSave.setLastName(LastName);
        agentLeadtoSave.setPhoneNumber(PhoneNumber);
        agentLeadtoSave.setEmail(Email);
        agentLeadtoSave.setSplitPercentage(SplitPercentage);
        AgentLeadsRepo.save(agentLeadtoSave);
        modelAndView.addObject("agentleadslist", AgentLeadsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "agentleads/edit/{id}", method = RequestMethod.GET)
    public ModelAndView agentleadsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("agentleadsedit");
        Optional<AgentLeadsEntity> AgentLead = AgentLeadsRepo.findById(id);
        AgentLeadsEntity agentlead = AgentLead.get();
        mv.addObject("selectedItem", agentlead);
        return mv;
    }
    @RequestMapping(value = "agentleads/delete/{id}", method = RequestMethod.GET)
    public ModelAndView agentleadsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/agentleads");
        AgentLeadsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ReferralsRepo ReferralsRepo;
    @RequestMapping("/referrals")
    public ModelAndView ReferralsPage(){
        ModelAndView modelAndView = new ModelAndView("referrals");
        modelAndView.addObject("referralslist", ReferralsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/referrals/save", method = RequestMethod.POST)
    public ModelAndView referralsave(
            @RequestParam("ReferralId") String ReferralId,
            @RequestParam("AgentId") int referralAgentId,
            @RequestParam("StatusId") int referralStatusId,
            @RequestParam("TypeId") int referralTypeId,
            @RequestParam("Date") String referralDate,
            @RequestParam("Percentage") int referralPercentage,
            @RequestParam("City") String referralCity,
            @RequestParam("StateId") int referralStateId,
            @RequestParam("ZipcodeId") int referralZipcodeId,
            @RequestParam("CountryId") int referralCountryId
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/referrals");
        ReferralsEntity referraltoSave;
        if(!ReferralId.isEmpty())
        {
            Optional<ReferralsEntity> referral =
                    ReferralsRepo.findById(Integer.parseInt(ReferralId));
            referraltoSave = referral.get();
        }
        else {
            referraltoSave = new ReferralsEntity();
        }
        referraltoSave.setAgentId(referralAgentId);
        referraltoSave.setStatusId(referralStatusId);
        referraltoSave.setTypeId(referralTypeId);
        referraltoSave.setDate(referralDate);
        referraltoSave.setPercentage(referralPercentage);
        referraltoSave.setCity(referralCity);
        referraltoSave.setStateId(referralStateId);
        referraltoSave.setZipcodeId(referralZipcodeId);
        referraltoSave.setCountryId(referralCountryId);
        ReferralsRepo.save(referraltoSave);
        modelAndView.addObject("referralslist", ReferralsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "referrals/edit/{id}", method = RequestMethod.GET)
    public ModelAndView referralsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("referralsedit");
        Optional<ReferralsEntity> Referrals = ReferralsRepo.findById(id);
        ReferralsEntity referral = Referrals.get();
        mv.addObject("selectedItem", referral);
        return mv;
    }
    @RequestMapping(value = "referrals/delete/{id}", method = RequestMethod.GET)
    public ModelAndView referralsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/referrals");
       ReferralsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ReferralStatusRepo ReferralStatusRepo;
    @RequestMapping("/referralstatus")
    public ModelAndView ReferralStatusPage(){
        ModelAndView modelAndView = new ModelAndView("referralstatus");
        modelAndView.addObject("referralstatuslist", ReferralStatusRepo.findAll());
        return modelAndView;
    }


    @Autowired
    ReferralTypesRepo ReferralTypesRepo;
    @RequestMapping("/referraltypes")
    public ModelAndView ReferralTypesPage(){
        ModelAndView modelAndView = new ModelAndView("referraltypes");
        modelAndView.addObject("referraltypeslist", ReferralTypesRepo.findAll());
        return modelAndView;
    }


    @Autowired
    AppointmentsRepo AppointmentsRepo;
    @RequestMapping("/appointments")
    public ModelAndView AppointmentsPage(){
        ModelAndView modelAndView = new ModelAndView("appointments");
        modelAndView.addObject("appointmentslist", AppointmentsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/appointments/save", method = RequestMethod.POST)
    public ModelAndView appointmentssave(
            @RequestParam("AppointmentId") String AppointmentId,
            @RequestParam("AgentId") int AppointmentAgentId,
            @RequestParam("ClientId") int AppointmentClientId,
            @RequestParam("TopicId") int AppointmentTopicId,
            @RequestParam("Date") String AppointmentDate,
            @RequestParam("Time") String AppointmentTime
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/appointments");
        AppointmentsEntity appointmenttoSave;
        if(!AppointmentId.isEmpty())
        {
            Optional<AppointmentsEntity> appointment =
                    AppointmentsRepo.findById(Integer.parseInt(AppointmentId));
            appointmenttoSave = appointment.get();
        }
        else {
            appointmenttoSave = new AppointmentsEntity();
        }
       appointmenttoSave.setAgentId(AppointmentAgentId);
       appointmenttoSave.setClientId(AppointmentClientId);
       appointmenttoSave.setTopicId(AppointmentTopicId);
       appointmenttoSave.setDate(AppointmentDate);
       appointmenttoSave.setTime(AppointmentTime);
       AppointmentsRepo.save(appointmenttoSave);
       modelAndView.addObject("appointmentslist", AppointmentsRepo.findAll());
       return modelAndView;
    }
    @RequestMapping( value = "appointments/edit/{id}", method = RequestMethod.GET)
    public ModelAndView appointmentsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("appointmentsedit");
        Optional<AppointmentsEntity> Appointment = AppointmentsRepo.findById(id);
        AppointmentsEntity appointment = Appointment.get();
        mv.addObject("selectedItem", appointment);
        return mv;
    }
    @RequestMapping(value = "appointments/delete/{id}", method = RequestMethod.GET)
    public ModelAndView appointmentsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/appointments");
        AppointmentsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    AppointmentTopicsRepo AppointmentTopicsRepo;
    @RequestMapping("/appointmenttopics")
    public ModelAndView AppointmentTopicsPage(){
        ModelAndView modelAndView = new ModelAndView("appointmenttopics");
        modelAndView.addObject("appointmenttopicslist", AppointmentTopicsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/appointmenttopics/save", method = RequestMethod.POST)
    public ModelAndView appointmenttopicsave(
            @RequestParam("AppointmentTopicId") String AppointmentTopicId,
            @RequestParam("Topic") String AppointmentTopicSave
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/appointmenttopics");
        AppointmentTopicsEntity apppointmentTopicToSave;
        if(!AppointmentTopicId.isEmpty())
        {
            Optional<AppointmentTopicsEntity> appointmenttopic =
                    AppointmentTopicsRepo.findById(Integer.parseInt(AppointmentTopicId));
            apppointmentTopicToSave = appointmenttopic.get();
        }
        else {
            apppointmentTopicToSave = new AppointmentTopicsEntity();
        }
      apppointmentTopicToSave.setTopic(AppointmentTopicSave);
        AppointmentTopicsRepo.save(apppointmentTopicToSave);
        modelAndView.addObject("appointmenttopicslist", AppointmentTopicsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "appointmenttopics/edit/{id}", method = RequestMethod.GET)
    public ModelAndView appointmenttopicsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("appointmenttopicsedit");
        Optional<AppointmentTopicsEntity> AppointmentTopic = AppointmentTopicsRepo.findById(id);
        AppointmentTopicsEntity appointmenttopic = AppointmentTopic.get();
        mv.addObject("selectedItem", appointmenttopic);
        return mv;
    }
    @RequestMapping(value = "appointmenttopics/delete/{id}", method = RequestMethod.GET)
    public ModelAndView appointmenttopicsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/appointmenttopics");
        AppointmentTopicsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    MarketingPlansRepo MarketingPlansRepo;
    @RequestMapping("/marketingplans")
    public ModelAndView MarketingPlansPage(){
        ModelAndView modelAndView = new ModelAndView("marketingplans");
        modelAndView.addObject("marketingplanslist", MarketingPlansRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/marketingplans/save", method = RequestMethod.POST)
    public ModelAndView marketplansave(
            @RequestParam("MarketingPlanId") String marketingPlanId,
            @RequestParam("ListingId") int marketingPlanListingId,
            @RequestParam("AgentId") int marketingPlanAgentId,
            @RequestParam("CampaignId") int marketingPlanCampaignId,
            @RequestParam("Date") String marketingPlanDate,
            @RequestParam("Source") String marketingPlanSource,
            @RequestParam("Format") String marketingPlanFormat,
            @RequestParam("Goal") String marketingPlanGoal
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/marketingplans");
        MarketingPlansEntity marketPlanToSave;
        if(!marketingPlanId.isEmpty())
        {
            Optional<MarketingPlansEntity> marketingplan =
                   MarketingPlansRepo.findById(Integer.parseInt(marketingPlanId));
            marketPlanToSave = marketingplan.get();
        }
        else {
            marketPlanToSave = new MarketingPlansEntity();
        }
        marketPlanToSave.setListingId(marketingPlanListingId);
        marketPlanToSave.setAgentId(marketingPlanAgentId);
        marketPlanToSave.setCampaignId(marketingPlanCampaignId);
        marketPlanToSave.setDate(marketingPlanDate);
        marketPlanToSave.setSource(marketingPlanSource);
        marketPlanToSave.setFormat(marketingPlanFormat);
        marketPlanToSave.setGoal(marketingPlanGoal);
        MarketingPlansRepo.save(marketPlanToSave);
        modelAndView.addObject("marketingplanslist", MarketingPlansRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "marketingplans/edit/{id}", method = RequestMethod.GET)
    public ModelAndView marketingplansedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("marketingplansedit");
        Optional<MarketingPlansEntity> MarketingPlan = MarketingPlansRepo.findById(id);
        MarketingPlansEntity marketingplan = MarketingPlan.get();
        mv.addObject("selectedItem", marketingplan);
        return mv;
    }
    @RequestMapping(value = "marketingplans/delete/{id}", method = RequestMethod.GET)
    public ModelAndView marketingplansdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/marketingplans");
        MarketingPlansRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    CampaignsRepo CampaignsRepo;
    @RequestMapping("/campaigns")
    public ModelAndView CampaignsPage(){
        ModelAndView modelAndView = new ModelAndView("campaigns");
        modelAndView.addObject("campaignslist", CampaignsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/campaigns/save", method = RequestMethod.POST)
    public ModelAndView campaignsave(
            @RequestParam("CampaignId") String CampaignId,
            @RequestParam("Title") String CampaignTitle,
            @RequestParam("Date") String CampaignDate
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/campaigns");
        CampaignsEntity campaignToSave;
        if(!CampaignId.isEmpty())
        {
            Optional<CampaignsEntity> campaign =
                    CampaignsRepo.findById(Integer.parseInt(CampaignId));
            campaignToSave = campaign.get();
        }
        else {
            campaignToSave = new CampaignsEntity();
        }
    campaignToSave.setTitle(CampaignTitle);
    campaignToSave.setDate(CampaignDate);
    CampaignsRepo.save(campaignToSave);
    modelAndView.addObject("campaignslist", CampaignsRepo.findAll());
    return modelAndView;
    }
    @RequestMapping( value = "campaigns/edit/{id}", method = RequestMethod.GET)
    public ModelAndView campaignssedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("campaignsedit");
        Optional<CampaignsEntity> Campaign = CampaignsRepo.findById(id);
        CampaignsEntity campaign = Campaign.get();
        mv.addObject("selectedItem", campaign);
        return mv;
    }
    @RequestMapping(value = "campaigns/delete/{id}", method = RequestMethod.GET)
    public ModelAndView campaignsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/campaigns");
        CampaignsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    OpenHousesRepo OpenHousesRepo;
    @RequestMapping("/openhouses")
    public ModelAndView OpenHousePage(){
        ModelAndView modelAndView = new ModelAndView("openhouses");
        modelAndView.addObject("openhouseslist", OpenHousesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/openhouses/save", method = RequestMethod.POST)
    public ModelAndView openhousesave(
            @RequestParam("OpenHouseId") String OpenHouseId,
            @RequestParam("ListingId") int openHouseListingId,
            @RequestParam("Time") String openHouseTime,
            @RequestParam("Date") String openHouseDate,
            @RequestParam("AgentId") int openHouseAgentId
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/openhouses");
        OpenHousesEntity openHouseToSave;
        if(!OpenHouseId.isEmpty())
        {
            Optional<OpenHousesEntity> openhouse =
                    OpenHousesRepo.findById(Integer.parseInt(OpenHouseId));
            openHouseToSave = openhouse.get();
        }
        else {
           openHouseToSave = new OpenHousesEntity();
        }
        openHouseToSave.setListingId(openHouseListingId);
        openHouseToSave.setTime(openHouseTime);
        openHouseToSave.setDate(openHouseDate);
        openHouseToSave.setAgentId(openHouseAgentId);
        OpenHousesRepo.save(openHouseToSave);
        modelAndView.addObject("openhouseslist", OpenHousesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "openhouses/edit/{id}", method = RequestMethod.GET)
    public ModelAndView openhousesedit(@PathVariable("id") int id){
       ModelAndView mv = new ModelAndView("openhousesedit");
       Optional<OpenHousesEntity> OpenHouse = OpenHousesRepo.findById(id);
       OpenHousesEntity openhouse = OpenHouse.get();
       mv.addObject("selectedItem", openhouse);
       return mv;
    }
    @RequestMapping(value = "openhouses/delete/{id}", method = RequestMethod.GET)
    public ModelAndView openhousesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/openhouses");
        OpenHousesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    SignedLeasesRepo SignedLeasesRepo;
    @RequestMapping("/signedleases")
    public ModelAndView SignedLeasesPage(){
        ModelAndView modelAndView = new ModelAndView("signedleases");
        modelAndView.addObject("signedleaseslist", SignedLeasesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/signedleases/save", method = RequestMethod.POST)
    public ModelAndView signedleasessave(
            @RequestParam("SignedLeaseId") String SignedLeaseId,
            @RequestParam("AgreementId") int signedLeaseAgreementId,
            @RequestParam("ClientId") int signedLeaseClientId,
            @RequestParam("Date") String signedLeaseDate
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/signedleases");
        SignedLeasesEntity signedLeaseToSave;
        if(!SignedLeaseId.isEmpty())
        {
            Optional<SignedLeasesEntity> signedlease =
                    SignedLeasesRepo.findById(Integer.parseInt(SignedLeaseId));
            signedLeaseToSave = signedlease.get();
        }
        else {
            signedLeaseToSave = new SignedLeasesEntity();
        }
        signedLeaseToSave.setAgreementId(signedLeaseAgreementId);
        signedLeaseToSave.setClientId(signedLeaseClientId);
        signedLeaseToSave.setDate(signedLeaseDate);
        SignedLeasesRepo.save(signedLeaseToSave);
        modelAndView.addObject("signedleaseslist", SignedLeasesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "signedleases/edit/{id}", method = RequestMethod.GET)
    public ModelAndView signedleasesedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("signedleasesedit");
        Optional<SignedLeasesEntity> SignedLease = SignedLeasesRepo.findById(id);
        SignedLeasesEntity signedlease = SignedLease.get();
        mv.addObject("selectedItem", signedlease);
        return mv;
    }
    @RequestMapping(value = "signedleases/delete/{id}", method = RequestMethod.GET)
    public ModelAndView signedleasesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/signedleases");
        SignedLeasesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    LeaseAgreementsRepo LeaseAgreementsRepo;
    @RequestMapping("/leaseagreements")
    public ModelAndView LeaseAgreementsPage(){
        ModelAndView modelAndView = new ModelAndView("leaseagreements");
        modelAndView.addObject("leaseagreementslist", LeaseAgreementsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/leaseagreements/save", method = RequestMethod.POST)
    public ModelAndView leaseagreementsave(
            @RequestParam("LeaseAgreementId") String AgreementId,
            @RequestParam("LeaseListingId") int AgreementLeaseListingId,
            @RequestParam("StartDate") String AgreementStartDate,
            @RequestParam("EndDate") String AgreementEndDate,
            @RequestParam("Pets") int AgreementPets,
            @RequestParam("Deposit") float AgreementDeposit
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/leaseagreements");
        LeaseAgreementsEntity leaseAgreementToSave;
        if(!AgreementId.isEmpty())
        {
            Optional<LeaseAgreementsEntity> agreement =
                    LeaseAgreementsRepo.findById(Integer.parseInt(AgreementId));
            leaseAgreementToSave = agreement.get();
        }
        else {
            leaseAgreementToSave = new LeaseAgreementsEntity();
        }
        leaseAgreementToSave.setLeaseListingId(AgreementLeaseListingId);
        leaseAgreementToSave.setLeaseStartDate(AgreementStartDate);
        leaseAgreementToSave.setLeaseEndDate(AgreementEndDate);
        leaseAgreementToSave.setNumberOfPets(AgreementPets);
        leaseAgreementToSave.setPetDeposit(AgreementDeposit);
        LeaseAgreementsRepo.save(leaseAgreementToSave);
        modelAndView.addObject("leaseagreementslist", LeaseAgreementsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "leaseagreements/edit/{id}", method = RequestMethod.GET)
    public ModelAndView leaseagreementsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("leaseagreementsedit");
        Optional<LeaseAgreementsEntity> LeaseAgreement = LeaseAgreementsRepo.findById(id);
        LeaseAgreementsEntity leaseagreements = LeaseAgreement.get();
        mv.addObject("selectedItem", leaseagreements);
        return mv;
    }
    @RequestMapping(value = "leaseagreements/delete/{id}", method = RequestMethod.GET)
    public ModelAndView leaseagreementsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/leaseagreements");
        LeaseAgreementsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    LeaseListingsRepo LeaseListingsRepo;
    @RequestMapping("/leaselistings")
    public ModelAndView LeaseListingsPage(){
        ModelAndView modelAndView = new ModelAndView("leaselistings");
        modelAndView.addObject("leaselistingslist", LeaseListingsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/leaselistings/save", method = RequestMethod.POST)
    public ModelAndView leaselistingsave(
            @RequestParam("LeaseListingId") String LeaseListingId,
            @RequestParam("ListingId") int addLeaseListingId,
            @RequestParam("StatusId") int leaseStatusId,
            @RequestParam("Laundry") String laundry,
            @RequestParam("Smoking") String smoking,
            @RequestParam("Dogs") String dog,
            @RequestParam("Cats") String cat,
            @RequestParam("MaximumWeight") int maximumWeight,
            @RequestParam("Rent") float rent,
            @RequestParam("Date") String leaseListingDate
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/leaselistings");
        LeaseListingsEntity leaselistingToSave;
        if(!LeaseListingId.isEmpty())
        {
            Optional<LeaseListingsEntity> leaselisting =
                    LeaseListingsRepo.findById(Integer.parseInt(LeaseListingId));
            leaselistingToSave = leaselisting.get();
        }
        else {
            leaselistingToSave = new LeaseListingsEntity();
        }
        leaselistingToSave.setListingId(addLeaseListingId);
        leaselistingToSave.setStatusId(leaseStatusId);
        leaselistingToSave.setLaundry(laundry);
        leaselistingToSave.setSmoking(smoking);
        leaselistingToSave.setDogsAllowed(dog);
        leaselistingToSave.setCatsAllowed(cat);
        leaselistingToSave.setMaximumWeight(maximumWeight);
        leaselistingToSave.setRent(rent);
        leaselistingToSave.setDate(leaseListingDate);
        LeaseListingsRepo.save(leaselistingToSave);
        modelAndView.addObject("leaselistingslist", LeaseListingsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "leaselistings/edit/{id}", method = RequestMethod.GET)
    public ModelAndView leaselistingsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("leaselistingsedit");
        Optional<LeaseListingsEntity> LeaseListing = LeaseListingsRepo.findById(id);
        LeaseListingsEntity leaselisting = LeaseListing.get();
        mv.addObject("selectedItem", leaselisting);
        return mv;
    }
    @RequestMapping(value = "leaselistings/delete/{id}", method = RequestMethod.GET)
    public ModelAndView leaselistingsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/leaselistings");
        LeaseListingsRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ListingFeaturesRepo ListingFeaturesRepo;
    @RequestMapping("/listingfeatures")
    public ModelAndView ListingFeaturesPage(){
        ModelAndView modelAndView = new ModelAndView("listingfeatures");
        modelAndView.addObject("listingfeatureslist", ListingFeaturesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/listingfeatures/save", method = RequestMethod.POST)
    public ModelAndView listingfeaturesave(
            @RequestParam("ListingFeatureId") String ListingFeatureId,
            @RequestParam("LeaseListingId") int LeaseListingId,
            @RequestParam("FeatureId") int FeatureId

    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/listingfeatures");
        ListingFeaturesEntity listingFeatureToSave;
        if(!ListingFeatureId.isEmpty())
        {
            Optional<ListingFeaturesEntity> listingfeature =
                    ListingFeaturesRepo.findById(Integer.parseInt(ListingFeatureId));
            listingFeatureToSave = listingfeature.get();
        }
        else {
            listingFeatureToSave = new ListingFeaturesEntity();
        }
        listingFeatureToSave.setLeaseListingId(LeaseListingId);
        listingFeatureToSave.setFeatureId(FeatureId);
        ListingFeaturesRepo.save(listingFeatureToSave);
        modelAndView.addObject("listingfeatureslist", ListingFeaturesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "listingfeatures/edit/{id}", method = RequestMethod.GET)
    public ModelAndView listingfeaturesedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("listingfeaturesedit");
        Optional<ListingFeaturesEntity> ListingFeatures = ListingFeaturesRepo.findById(id);
        ListingFeaturesEntity listingfeature = ListingFeatures.get();
        mv.addObject("selectedItem", listingfeature);
        return mv;
    }
    @RequestMapping(value = "listingfeatures/delete/{id}", method = RequestMethod.GET)
    public ModelAndView listingfeaturesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/listingfeatures");
        ListingFeaturesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    FeaturesRepo FeaturesRepo;
    @RequestMapping("/features")
    public ModelAndView FeaturesPage(){
        ModelAndView modelAndView = new ModelAndView("features");
        modelAndView.addObject("featureslist", FeaturesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/features/save", method = RequestMethod.POST)
    public ModelAndView featuresave(
            @RequestParam("FeatureId") String FeatureId,
            @RequestParam("Feature") String Feature
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/features");
        FeaturesEntity featureToSave;
        if(!FeatureId.isEmpty())
        {
            Optional<FeaturesEntity> feature =
                    FeaturesRepo.findById(Integer.parseInt(FeatureId));
            featureToSave = feature.get();
        }
        else {
            featureToSave = new FeaturesEntity();
        }
        featureToSave.setFeature(Feature);
        FeaturesRepo.save(featureToSave);
        modelAndView.addObject("featureslist", FeaturesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "features/edit/{id}", method = RequestMethod.GET)
    public ModelAndView featuresedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("featuresedit");
        Optional<FeaturesEntity> Feature = FeaturesRepo.findById(id);
        FeaturesEntity feature = Feature.get();
        mv.addObject("selectedItem", feature);
        return mv;
    }
    @RequestMapping(value = "features/delete/{id}", method = RequestMethod.GET)
    public ModelAndView featuresdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/features");
        FeaturesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ListingAmenitiesRepo ListingAmenitiesRepo;
    @RequestMapping("/listingamenities")
    public ModelAndView ListingAmenitiesPage(){
        ModelAndView modelAndView = new ModelAndView("listingamenities");
        modelAndView.addObject("listingamenitieslist", ListingAmenitiesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/listingamenities/save", method = RequestMethod.POST)
    public ModelAndView listingamenitysave(
            @RequestParam("ListingAmenitiesId") String ListingAmenitiesId,
            @RequestParam("LeaseListingId") int AmLeaseListingId,
            @RequestParam("AmenityId") int AmAmenityId
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/listingamenities");
        ListingAmenitiesEntity listingAmenityToSave;
        if(!ListingAmenitiesId.isEmpty())
        {
            Optional<ListingAmenitiesEntity> listingamenity =
                    ListingAmenitiesRepo.findById(Integer.parseInt(ListingAmenitiesId));
            listingAmenityToSave = listingamenity.get();
        }
        else {
           listingAmenityToSave = new ListingAmenitiesEntity();
        }
        listingAmenityToSave.setLeaseListingId(AmLeaseListingId);
        listingAmenityToSave.setAmenityId(AmAmenityId);
        ListingAmenitiesRepo.save(listingAmenityToSave);
        modelAndView.addObject("listingamenitieslist", ListingAmenitiesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "listingamenities/edit/{id}", method = RequestMethod.GET)
    public ModelAndView listingamenitiesedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("listingamenitiesedit");
        Optional<ListingAmenitiesEntity> ListingAmenity = ListingAmenitiesRepo.findById(id);
        ListingAmenitiesEntity listingamenity = ListingAmenity.get();
        mv.addObject("selectedItem", listingamenity);
        return mv;
    }
    @RequestMapping(value = "listingamenities/delete/{id}", method = RequestMethod.GET)
    public ModelAndView listingamenitiesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/listingamenities");
        ListingAmenitiesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    AmenitiesRepo AmenitiesRepo;
    @RequestMapping("/amenities")
    public ModelAndView AmenitiesPage(){
        ModelAndView modelAndView = new ModelAndView("amenities");
        modelAndView.addObject("amenitieslist", AmenitiesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/amenities/save", method = RequestMethod.POST)
    public ModelAndView amenitysave(
            @RequestParam("AmenityId") String AmenityId,
            @RequestParam("Amenity") String Amenity
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/amenities");
        AmenitiesEntity amenityToSave = new AmenitiesEntity(Amenity);
        AmenitiesRepo.save(amenityToSave);
        modelAndView.addObject("amenitieslist", AmenitiesRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "amenities/edit/{id}", method = RequestMethod.GET)
    public ModelAndView amenitiesedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("amenitiesedit");
        Optional<AmenitiesEntity> Amenity = AmenitiesRepo.findById(id);
        AmenitiesEntity amenity = Amenity.get();
        mv.addObject("selectedItem", amenity);
        return mv;
    }
    @RequestMapping(value = "amenities/delete/{id}", method = RequestMethod.GET)
    public ModelAndView amenitiesdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/amenities");
        AmenitiesRepo.deleteById(id);
        return modelAndView;
    }


    @Autowired
    ListingStatusRepo ListingStatusRepo;
    @RequestMapping("/listingstatus")
    public ModelAndView ListingStatusPage(){
        ModelAndView modelAndView = new ModelAndView("listingstatus");
        modelAndView.addObject("listingstatuslist", ListingStatusRepo.findAll());
        return modelAndView;
    }


    @Autowired
    SalelistingsRepo SaleListingsRepo;
    @RequestMapping("/salelistings")
    public ModelAndView SaleListingsPage(){
        ModelAndView modelAndView = new ModelAndView("salelistings");
        modelAndView.addObject("salelistingslist", SaleListingsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping(value = "/salelistings/save", method = RequestMethod.POST)
    public ModelAndView salelistingsave(
            @RequestParam("SaleListingId") String SaleListingId,
            @RequestParam("ListingId") int ListingId,
            @RequestParam("StatusId") int saleStatusId,
            @RequestParam("ListingPrice") float saleListingPrice,
            @RequestParam("YearBuilt") String yearBuilt,
            @RequestParam("ChristieListing") String christiesListing,
            @RequestParam("Date") String saleDate
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/salelistings");
        SaleListingsEntity salelistingToSave;
        if(!SaleListingId.isEmpty())
        {
            Optional<SaleListingsEntity> salelisting =
                    SaleListingsRepo.findById(Integer.parseInt(SaleListingId));
            salelistingToSave = salelisting.get();
        }
        else {
            salelistingToSave = new SaleListingsEntity();
        }
        salelistingToSave.setListingId(ListingId);
        salelistingToSave.setStatusId(saleStatusId);
        salelistingToSave.setListingPrice(saleListingPrice);
        salelistingToSave.setYearBuilt(yearBuilt);
        salelistingToSave.setChristiesListing(christiesListing);
        salelistingToSave.setDate(saleDate);
        SaleListingsRepo.save(salelistingToSave);
        modelAndView.addObject("salelistingslist", SaleListingsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "salelistings/edit/{id}", method = RequestMethod.GET)
    public ModelAndView salelistingsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("salelistingsedit");
        Optional<SaleListingsEntity> SaleListings = SaleListingsRepo.findById(id);
        SaleListingsEntity salelistings = SaleListings.get();
        mv.addObject("selectedItem", salelistings);
        return mv;
    }
    @RequestMapping(value = "salelistings/delete/{id}", method = RequestMethod.GET)
    public ModelAndView salelistingsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/salelistings");
        SaleListingsRepo.deleteById(id);
        return modelAndView;
    }

    @Autowired
    TransactionsRepo TransactionsRepo;
    @RequestMapping("/transactions")
    public ModelAndView TransactionsPage(){
        ModelAndView modelAndView = new ModelAndView("transactions");
        modelAndView.addObject("transactionslist", TransactionsRepo.findAll());
        return modelAndView;
    }@RequestMapping(value = "/transactions/save", method = RequestMethod.POST)
    public ModelAndView transactionsave(
            @RequestParam("TransactionId") String transactionId,
            @RequestParam("SaleListingId") int saleListingId,
            @RequestParam("PaymentTypeId") int paymentTypeId,
            @RequestParam("SoldPrice") float soldPrice,
            @RequestParam("ComissionPercentage") int comissionPercentage,
            @RequestParam("Date") String date
    ) {
        ModelAndView modelAndView = new ModelAndView("redirect:/transactions");
        TransactionsEntity transactionToSave;
        if(!transactionId.isEmpty())
        {
            Optional<TransactionsEntity> transaction =
                    TransactionsRepo.findById(Integer.parseInt(transactionId));
            transactionToSave = transaction.get();
        }
        else {
            transactionToSave = new TransactionsEntity();
        }
        transactionToSave.setSaleListingId(saleListingId);
        transactionToSave.setPaymentTypeId(paymentTypeId);
        transactionToSave.setSoldPrice(soldPrice);
        transactionToSave.setComissionPercentage(comissionPercentage);
        transactionToSave.setDate(date);
        TransactionsRepo.save(transactionToSave);
        modelAndView.addObject("transactionslist", TransactionsRepo.findAll());
        return modelAndView;
    }
    @RequestMapping( value = "transactions/edit/{id}", method = RequestMethod.GET)
    public ModelAndView transactionsedit(@PathVariable("id") int id){
        ModelAndView mv = new ModelAndView("transactionsedit");
        Optional<TransactionsEntity> Transaction = TransactionsRepo.findById(id);
        TransactionsEntity transaction = Transaction.get();
        mv.addObject("selectedItem", transaction);
        return mv;
    }
    @RequestMapping(value = "transactions/delete/{id}", method = RequestMethod.GET)
    public ModelAndView transactionsdelete(@PathVariable("id") int id){
        ModelAndView modelAndView = new ModelAndView("redirect:/transactions");
        TransactionsRepo.deleteById(id);
        return modelAndView;
    }

    @Autowired
    PropertyTypeRepo PropertyTypeRepo;
    @RequestMapping("/propertytypes")
    public ModelAndView PropertyTypePage(){
        ModelAndView modelAndView = new ModelAndView("propertytypes");
        modelAndView.addObject("propertytypeslist", PropertyTypeRepo.findAll());
        return modelAndView;
    }


    @Autowired
    PaymentTypesRepo PaymentTypesRepo;
    @RequestMapping("/paymenttype")
    public ModelAndView PaymentTypesPage(){
        ModelAndView modelAndView = new ModelAndView("paymenttype");
        modelAndView.addObject("paymenttypelist", PaymentTypesRepo.findAll());
        return modelAndView;
    }

}