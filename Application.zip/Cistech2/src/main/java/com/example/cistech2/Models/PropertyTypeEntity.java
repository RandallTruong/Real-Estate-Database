package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "propertytype")
public class PropertyTypeEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "property_id")
    private int PropertyId;
    @Column(name = "property_type")
    private String PropertyType;
    @Column(name = "description")
    private String Description;

    public PropertyTypeEntity() {
    }

    public PropertyTypeEntity(String propertyType, String description) {
        PropertyType = propertyType;
        Description = description;
    }


    public int getPropertyId() {
        return PropertyId;
    }

    public void setPropertyId(int propertyId) {
        PropertyId = propertyId;
    }

    public String getPropertyType() {
        return PropertyType;
    }

    public void setPropertyType(String propertyType) {
        PropertyType = propertyType;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}
