package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "courses")
public class CoursesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
   @Column(name = "course_id")
    private int CourseId;
   @Column(name = "bootcamp_id")
    private int BootcampId;
   @Column(name = "title")
    private String title;

   public CoursesEntity() {
    }

    public CoursesEntity(int bootcampId, String title) {
        BootcampId = bootcampId;
        this.title = title;
    }

    public int getCourseId() {
        return CourseId;
    }

    public void setCourseId(int courseId) {
        CourseId = courseId;
    }

    public int getBootcampId() {
        return BootcampId;
    }

    public void setBootcampId(int bootcampId) {
        BootcampId = bootcampId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


}
