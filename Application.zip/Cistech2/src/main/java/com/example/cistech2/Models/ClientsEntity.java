package com.example.cistech2.Models;

import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "clients")
public class ClientsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "client_id")
    private int ClientId;
    @Column(name = "company_id")
    private int CompanyId;
    @Column(name = "agent_id")
    private int AgentId;
    @Column(name ="first_name")
    private String FirstName;
    @Column(name ="last_name")
    private String LastName;
    @Column(name = "address")
    private String Address;
    @Column(name = "city")
    private String City;
    @Column(name = "state_id")
    private int StateId;
    @Column(name = "zipcode_id")
    private int ZipcodeId;
    @Column(name = "country_id")
    private int CountryId;
    @Column(name = "phone_number")
    private String PhoneNumber;
    @Column (name = "email")
    private String Email;

    public ClientsEntity() {
    }

    public ClientsEntity(int companyId, int agentId, String firstName, String lastName, String address, String city,
                         int stateId, int zipcodeId, int countryId, String phoneNumber, String email) {
        CompanyId = companyId;
        AgentId = agentId;
        FirstName = firstName;
        LastName = lastName;
        Address = address;
        City = city;
        StateId = stateId;
        ZipcodeId = zipcodeId;
        CountryId = countryId;
        PhoneNumber = phoneNumber;
        Email = email;

    }

    public int getClientId() {
        return ClientId;
    }

    public void setClientId(int clientId) {
        ClientId = clientId;
    }

    public int getCompanyId() {
        return CompanyId;
    }

    public void setCompanyId(int companyId) {
        CompanyId = companyId;
    }

    public int getAgentId() {
        return AgentId;
    }

    public void setAgentId(int agentId) {
        AgentId = agentId;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public int getStateId() {
        return StateId;
    }

    public void setStateId(int stateId) {
        StateId = stateId;
    }

    public int getZipcodeId() {
        return ZipcodeId;
    }

    public void setZipcodeId(int zipcodeId) {
        ZipcodeId = zipcodeId;
    }

    public int getCountryId() {
        return CountryId;
    }

    public void setCountryId(int countryId) {
        CountryId = countryId;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

}
