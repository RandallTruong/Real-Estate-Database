package com.example.cistech2.Models;

import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "countries")
public class CountriesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Id
   @Column(name = "country_id")
   private int CountryId;
   @Column(name = "Country")
    private String Country;


    public CountriesEntity() {
    }

    public CountriesEntity(String country) {
        Country = country;
    }

    public int getCountryId() {
        return CountryId;
    }

    public void setCountryId(int countryId) {
        CountryId = countryId;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

}
