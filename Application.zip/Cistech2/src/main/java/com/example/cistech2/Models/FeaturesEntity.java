package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "features")
public class FeaturesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "feature_id")
    private int FeatureId;
    @Column(name = "feature")
    private String Feature;


    public FeaturesEntity() {
    }

    public FeaturesEntity(String feature) {
        Feature = feature;
    }

    public int getFeatureId() {
        return FeatureId;
    }

    public void setFeatureId(int featureId) {
        FeatureId = featureId;
    }

    public String getFeature() {
        return Feature;
    }

    public void setFeature(String feature) {
        Feature = feature;
    }

}
