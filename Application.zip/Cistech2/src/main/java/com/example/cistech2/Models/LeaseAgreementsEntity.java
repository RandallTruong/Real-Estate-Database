package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "leaseagreements")
public class LeaseAgreementsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "agreement_id")
    private int AgreementId;
    @Column(name = "lease_listing_id")
    private int LeaseListingId;
    @Column(name = "lease_Start_Date")
    private String LeaseStartDate;
    @Column(name = "lease_End_Date")
    private String LeaseEndDate;
    @Column(name = "number_of_pets")
    private int NumberOfPets;
    @Column(name = "pet_deposit")
    private float PetDeposit;


    public LeaseAgreementsEntity() {
    }

    public LeaseAgreementsEntity(int leaseListingId, String leaseStartDate, String leaseEndDate,
                                 int numberOfPets, float petDeposit) {
        LeaseListingId = leaseListingId;
        LeaseStartDate = leaseStartDate;
        LeaseEndDate = leaseEndDate;
        NumberOfPets = numberOfPets;
        PetDeposit = petDeposit;
    }

    public int getAgreementId() {
        return AgreementId;
    }

    public void setAgreementId(int agreementId) {
        AgreementId = agreementId;
    }

    public int getLeaseListingId() {
        return LeaseListingId;
    }

    public void setLeaseListingId(int leaseListingId) {
        LeaseListingId = leaseListingId;
    }

    public String getLeaseStartDate() {
        return LeaseStartDate;
    }

    public void setLeaseStartDate(String leaseStartDate) {
        LeaseStartDate = leaseStartDate;
    }

    public int getNumberOfPets() {
        return NumberOfPets;
    }

    public void setNumberOfPets(int numberOfPets) {
        NumberOfPets = numberOfPets;
    }

    public float getPetDeposit() {
        return PetDeposit;
    }

    public void setPetDeposit(float petDeposit) {
        PetDeposit = petDeposit;
    }

    public String getLeaseEndDate() {
        return LeaseEndDate;
    }

    public void setLeaseEndDate(String leaseEndDate) {
        LeaseEndDate = leaseEndDate;
    }
}
