package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "bootcamps")
public class BootcampsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "bootcamp_id")
    private int BootcampId;
    @Column(name = "program_id")
    private int ProgramId;
    @Column(name="title")
    private String title;


    public BootcampsEntity(int programId, String title) {
        ProgramId = programId;
        this.title = title;
    }

    public BootcampsEntity() {
    }

    public int getBootcampId() {
        return BootcampId;
    }

    public void setBootcampId(int bootcampId) {
        BootcampId = bootcampId;
    }

    public int getProgramId() {
        return ProgramId;
    }

    public void setProgramId(int programId) {
        ProgramId = programId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


}
