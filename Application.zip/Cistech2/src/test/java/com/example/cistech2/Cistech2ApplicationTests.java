package com.example.cistech2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cistech2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
