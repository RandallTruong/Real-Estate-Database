package com.example.cistech2.Repositories;

import com.example.cistech2.Models.EquipmentEntity;
import org.springframework.data.repository.CrudRepository;

public interface EquipmentRepo extends CrudRepository<EquipmentEntity, Integer> {

}
