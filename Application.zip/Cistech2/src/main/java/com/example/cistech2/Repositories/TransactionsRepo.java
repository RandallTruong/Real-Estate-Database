package com.example.cistech2.Repositories;

import com.example.cistech2.Models.TransactionsEntity;
import org.springframework.data.repository.CrudRepository;

public interface TransactionsRepo extends CrudRepository<TransactionsEntity, Integer> {

}
