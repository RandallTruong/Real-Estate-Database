package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "complaints")
public class ComplaintsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "complaint_id")
    private int ComplaintId;
    @Column(name = "company_id")
    private int CompanyId;
    @Column(name = "nature_of_complaint")
    private String NatureOfComplaint;
    @Column(name = "description")
    private String Description;
    @Column(name = "date")
    private String Date;

    public ComplaintsEntity() {
    }

    public ComplaintsEntity(int companyId, String natureOfComplaint,
                            String description, String date) {

        CompanyId = companyId;
        NatureOfComplaint = natureOfComplaint;
        Description = description;
        Date = date;
    }

    public int getComplaintId() {
        return ComplaintId;
    }

    public void setComplaintId(int complaintId) {
        ComplaintId = complaintId;
    }

    public int getCompanyId() {
        return CompanyId;
    }

    public void setCompanyId(int companyId) {
        CompanyId = companyId;
    }

    public String getNatureOfComplaint() {
        return NatureOfComplaint;
    }

    public void setNatureOfComplaint(String natureOfComplaint) {
        NatureOfComplaint = natureOfComplaint;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }


}
