package com.example.cistech2.Repositories;

import com.example.cistech2.Models.CompanyLeadsEntity;
import org.springframework.data.repository.CrudRepository;

public interface CompanyLeadsRepo extends CrudRepository<CompanyLeadsEntity, Integer> {

}