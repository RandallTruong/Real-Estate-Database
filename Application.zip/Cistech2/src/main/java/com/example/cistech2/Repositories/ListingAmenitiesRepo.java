package com.example.cistech2.Repositories;

import com.example.cistech2.Models.ListingAmenitiesEntity;
import org.springframework.data.repository.CrudRepository;

public interface ListingAmenitiesRepo extends CrudRepository<ListingAmenitiesEntity, Integer> {

}
