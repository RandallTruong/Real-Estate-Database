package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "companyleads")
public class CompanyLeadsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "company_lead_id")
    private int CompanyLeadId;
    @Column(name = "company_id")
    private int CompanyId;
    @Column(name = "first_name")
    private String FirstName;
    @Column(name = "last_name")
    private String LastName;
    @Column(name = "phone_number")
    private String PhoneNumber;
    @Column(name = "email")
    private String Email;


    public CompanyLeadsEntity() {
    }

    public CompanyLeadsEntity(int companyId, String firstName,
                              String lastName, String phoneNumber, String email) {
        CompanyId = companyId;
        FirstName = firstName;
        LastName = lastName;
        PhoneNumber = phoneNumber;
        Email = email;
    }
    public int getCompanyLeadId() {
        return CompanyLeadId;
    }

    public void setCompanyLeadId(int companyLeadId) {
        CompanyLeadId = companyLeadId;
    }

    public int getCompanyId() {
        return CompanyId;
    }

    public void setCompanyId(int companyId) {
        CompanyId = companyId;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

}
