package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "roletypes")
public class RoleTypesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "role_type_id")
    private int RoleTypeId;
    @Column(name = "role_type")
    private String RoleType;
    @Column(name = "description")
    private String Description;

    public RoleTypesEntity() {
    }

    public RoleTypesEntity(String roleType, String description) {
        RoleType = roleType;
        Description = description;
    }

    public int getRoleTypeId() {
        return RoleTypeId;
    }

    public void setRoleTypeId(int roleTypeId) {
        RoleTypeId = roleTypeId;
    }

    public String getRoleType() {
        return RoleType;
    }

    public void setRoleType(String roleType) {
        RoleType = roleType;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}
