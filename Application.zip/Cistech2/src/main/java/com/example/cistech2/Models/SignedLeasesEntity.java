package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "signedleases")
public class SignedLeasesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "signed_lease_id")
    private int SignedLeaseId;
    @Column(name = "agreement_id")
    private int AgreementId;
    @Column(name = "client_id")
    private int ClientId;
    @Column(name = "date")
    private String Date;


    public SignedLeasesEntity() {
    }


    public SignedLeasesEntity(int agreementId, int clientId, String date) {
        AgreementId = agreementId;
        ClientId = clientId;
        Date = date;
    }

    public int getSignedLeaseId() {
        return SignedLeaseId;
    }

    public void setSignedLeaseId(int signedLeaseId) {
        SignedLeaseId = signedLeaseId;
    }

    public int getAgreementId() {
        return AgreementId;
    }

    public void setAgreementId(int agreementId) {
        AgreementId = agreementId;
    }

    public int getClientId() {
        return ClientId;
    }

    public void setClientId(int clientId) {
        ClientId = clientId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
