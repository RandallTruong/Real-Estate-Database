package com.example.cistech2.Repositories;

import com.example.cistech2.Models.InstructorsEntity;
import org.springframework.data.repository.CrudRepository;

public interface InstructorsRepo extends CrudRepository<InstructorsEntity, Integer> {

}