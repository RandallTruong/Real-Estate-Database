package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "socialmedia")
public class SocialMediaEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "social_media_id")
    private int SocialMediaId;
    @Column(name = "company_id")
    private int CompanyId;
    @Column(name = "platform")
    private String Platform;
    @Column(name = "account_name")
    private String AccountName;

    public SocialMediaEntity() {
    }

    public SocialMediaEntity(int companyId, String platform, String accountName) {
        CompanyId = companyId;
        Platform = platform;
        AccountName = accountName;
    }

    public int getSocialMediaId() {
        return SocialMediaId;
    }

    public void setSocialMediaId(int socialMediaId) {
        SocialMediaId = socialMediaId;
    }

    public int getCompanyId() {
        return CompanyId;
    }

    public void setCompanyId(int companyId) {
        CompanyId = companyId;
    }

    public String getPlatform() {
        return Platform;
    }

    public void setPlatform(String platform) {
        Platform = platform;
    }

    public String getAccountName() {
        return AccountName;
    }

    public void setAccountName(String accountName) {
        AccountName = accountName;
    }
}
