package com.example.cistech2.Models;

import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "grades")
public class GradesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "grade_id")
    private int GradeId;
    @Column(name = "employee_id")
    private int EmployeeId;
    @Column(name = "bootcamp_id")
    private int BootcampId;
    @Column(name = "grade")
    private String Grade;


    public GradesEntity() {
    }

    public GradesEntity(int employeeId, int bootcampId, String grade) {
        EmployeeId = employeeId;
        BootcampId = bootcampId;
        Grade = grade;
    }

    public int getGradeId() {
        return GradeId;
    }

    public void setGradeId(int gradeId) {
        GradeId = gradeId;
    }

    public int getEmployeeId() {
        return EmployeeId;
    }

    public void setEmployeeId(int employeeId) {
        EmployeeId = employeeId;
    }

    public int getBootcampId() {
        return BootcampId;
    }

    public void setBootcampId(int bootcampId) {
        BootcampId = bootcampId;
    }

    public String getGrade() {
        return Grade;
    }

    public void setGrade(String grade) {
        Grade = grade;
    }
}
