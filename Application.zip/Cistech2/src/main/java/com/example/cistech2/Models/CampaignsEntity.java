package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "campaigns")
public class CampaignsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "campaign_id")
    private int CampaignId;
    @Column(name = "title")
    private String title;
    @Column(name = "date")
    private String date;


    public CampaignsEntity() {
    }

    public CampaignsEntity(String title, String date) {
        this.title = title;
        this.date = date;
    }

    public int getCampaignId() {
        return CampaignId;
    }

    public void setCampaignId(int campaignId) {
        CampaignId = campaignId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
