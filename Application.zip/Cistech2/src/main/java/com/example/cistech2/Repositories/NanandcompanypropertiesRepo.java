package com.example.cistech2.Repositories;

import com.example.cistech2.Models.NanandcompanypropertiesEntity;
import org.springframework.data.repository.CrudRepository;

public interface NanandcompanypropertiesRepo extends CrudRepository<NanandcompanypropertiesEntity, Integer> {

}

