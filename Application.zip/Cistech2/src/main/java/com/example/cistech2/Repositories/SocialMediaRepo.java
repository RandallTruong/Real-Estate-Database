package com.example.cistech2.Repositories;
import com.example.cistech2.Models.SocialMediaEntity;
import org.springframework.data.repository.CrudRepository;

public interface SocialMediaRepo extends CrudRepository<SocialMediaEntity, Integer> {

}