package com.example.cistech2.Repositories;

import com.example.cistech2.Models.InfractionsEntity;
import org.springframework.data.repository.CrudRepository;

public interface InfractionsRepo extends CrudRepository<InfractionsEntity, Integer> {

        }