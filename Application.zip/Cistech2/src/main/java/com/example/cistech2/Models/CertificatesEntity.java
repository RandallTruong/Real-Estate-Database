package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "certificates")
public class CertificatesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "certificate_id")
    private int CertificateId;
    @Column(name = "grade_id")
    private int GradeId;
    @Column(name = "certification")
    private String Certification;


    public CertificatesEntity() {
    }

    public CertificatesEntity(int gradeId, String certification) {
        GradeId = gradeId;
        Certification = certification;
    }

    public int getCertificateId() {
        return CertificateId;
    }

    public void setCertificateId(int certificateId) {
        CertificateId = certificateId;
    }

    public int getGradeId() {
        return GradeId;
    }

    public void setGradeId(int gradeId) {
        GradeId = gradeId;
    }

    public String getCertification() {
        return Certification;
    }

    public void setCertification(String certification) {
        Certification = certification;
    }


}
