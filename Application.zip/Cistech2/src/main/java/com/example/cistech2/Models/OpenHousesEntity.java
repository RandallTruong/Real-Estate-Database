package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "openhouses")
public class OpenHousesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "open_house_id")
    private int OpenHouseId;
    @Column(name = "listing_id")
    private int ListingId;
    @Column(name = "time")
    private String Time;
    @Column(name = "date")
    private String Date;
    @Column(name = "agent_id")
    private int AgentId;


    public OpenHousesEntity() {
    }

    public OpenHousesEntity(int listingId, String time, String date, int agentId) {
        ListingId = listingId;
        Time = time;
        Date = date;
        AgentId = agentId;
    }

    public int getListingId() {
        return ListingId;
    }

    public void setListingId(int listingId) {
        ListingId = listingId;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public int getAgentId() {
        return AgentId;
    }

    public void setAgentId(int agentId) {
        AgentId = agentId;
    }

    public int getOpenHouseId() {
        return OpenHouseId;
    }
    public void setOpenHouseId(int openHouseId) {
        OpenHouseId = openHouseId;
    }
}
