package com.example.cistech2.Repositories;

import com.example.cistech2.Models.CountriesEntity;
import org.springframework.data.repository.CrudRepository;

public interface CountriesRepo extends CrudRepository<CountriesEntity, Integer> {
}
