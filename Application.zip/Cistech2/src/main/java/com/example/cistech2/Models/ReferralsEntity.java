package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "referrals")
public class ReferralsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "referral_id")
    private int ReferralId;
    @Column(name = "agent_id")
    private int AgentId;
    @Column(name = "status_id")
    private int StatusId;
    @Column(name = "type_id")
    private int TypeId;
    @Column(name = "date")
    private String Date;
    @Column(name = "percentage")
    private int Percentage;
    @Column(name = "city")
    private String City;
    @Column(name = "state_id")
    private int StateId;
    @Column(name = "zipcode_id")
    private int ZipcodeId;
    @Column(name = "country_id")
    private int CountryId;

    public ReferralsEntity() {
    }

    public ReferralsEntity(int agentId, int statusId, int typeId, String date,
                           int percentage, String city, int stateId, int zipcodeId, int countryId) {
        AgentId = agentId;
        StatusId = statusId;
        TypeId = typeId;
        Date = date;
        Percentage = percentage;
        City = city;
        StateId = stateId;
        ZipcodeId = zipcodeId;
        CountryId = countryId;
    }


    public int getReferralId() {
        return ReferralId;
    }

    public void setReferralId(int referralId) {
        ReferralId = referralId;
    }

    public int getAgentId() {
        return AgentId;
    }

    public void setAgentId(int agentId) {
        AgentId = agentId;
    }

    public int getStatusId() {
        return StatusId;
    }

    public void setStatusId(int statusId) {
        StatusId = statusId;
    }

    public int getTypeId() {
        return TypeId;
    }

    public void setTypeId(int typeId) {
        TypeId = typeId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public int getPercentage() {
        return Percentage;
    }

    public void setPercentage(int percentage) {
        Percentage = percentage;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public int getStateId() {
        return StateId;
    }

    public void setStateId(int stateId) {
        StateId = stateId;
    }

    public int getZipcodeId() {
        return ZipcodeId;
    }

    public void setZipcodeId(int zipcodeId) {
        ZipcodeId = zipcodeId;
    }

    public int getCountryId() {
        return CountryId;
    }

    public void setCountryId(int countryId) {
        CountryId = countryId;
    }
}
