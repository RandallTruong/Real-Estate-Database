package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "leaselistings")
public class LeaseListingsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "lease_listing_id")
    private int LeaseListingId;
    @Column(name = "listing_id")
    private int ListingId;
    @Column(name = "status_id")
    private int StatusId;
    @Column(name = "laundry")
    private String Laundry;
    @Column(name = "smoking")
    private String Smoking;
    @Column(name = "dogs_allowed")
    private String DogsAllowed;
    @Column(name = "cats_allowed")
    private String CatsAllowed;
    @Column(name = "maximum_weight")
    private int MaximumWeight;
    @Column (name = "rent")
    private float Rent;
    @Column (name = "date")
    private String Date;


    public LeaseListingsEntity() {
    }

    public LeaseListingsEntity(int listingId, int statusId, String laundry, String smoking,
                               String dogsAllowed, String catsAllowed, int maximumWeight, float rent, String date) {
        ListingId = listingId;
        StatusId = statusId;
        Laundry = laundry;
        Smoking = smoking;
        DogsAllowed = dogsAllowed;
        CatsAllowed = catsAllowed;
        MaximumWeight = maximumWeight;
        Rent = rent;
        Date = date;
    }

    public int getLeaseListingId() {
        return LeaseListingId;
    }

    public void setLeaseListingId(int leaseListingId) {
        LeaseListingId = leaseListingId;
    }

    public int getListingId() {
        return ListingId;
    }

    public void setListingId(int listingId) {
        ListingId = listingId;
    }

    public int getStatusId() {
        return StatusId;
    }

    public void setStatusId(int statusId) {
        StatusId = statusId;
    }

    public String getLaundry() {
        return Laundry;
    }

    public void setLaundry(String laundry) {
        Laundry = laundry;
    }

    public String getSmoking() {
        return Smoking;
    }

    public void setSmoking(String smoking) {
        Smoking = smoking;
    }

    public String getDogsAllowed() {
        return DogsAllowed;
    }

    public void setDogsAllowed(String dogsAllowed) {
        DogsAllowed = dogsAllowed;
    }

    public String getCatsAllowed() {
        return CatsAllowed;
    }

    public void setCatsAllowed(String catsAllowed) {
        CatsAllowed = catsAllowed;
    }

    public int getMaximumWeight() {
        return MaximumWeight;
    }

    public void setMaximumWeight(int maximumWeight) {
        MaximumWeight = maximumWeight;
    }

    public float getRent() {
        return Rent;
    }

    public void setRent(float rent) {
        Rent = rent;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
