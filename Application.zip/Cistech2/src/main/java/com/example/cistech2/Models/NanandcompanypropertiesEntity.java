package com.example.cistech2.Models;

import net.bytebuddy.dynamic.loading.InjectionClassLoader;

import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "nanandcompanyproperties")
public class NanandcompanypropertiesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "company_id")
    private int CompanyId;
    @Column(name = "administration")
    private String Administration;
    @Column(name = "address")
    private String Address;
    @Column(name = "city")
    private String City;
    @Column(name = "state_id")
    private int StateId;
    @Column(name = "zipcode_id")
    private int ZipcodeId;
    @Column(name = "country_id")
    private int CountryId;
    @Column(name = "phone_number")
    private String PhoneNumber;
    @Column(name = "email")
    private String Email;


    public NanandcompanypropertiesEntity() {

    }


    public NanandcompanypropertiesEntity(String Administration, String Address,
                                   String City, int StateId, int ZipcodeId,
                                   int CountryId, String PhoneNumber, String Email) {
        this.Administration = Administration;
        this.Address = Address;
        this.City = City;
        this.StateId = StateId;
        this.ZipcodeId = ZipcodeId;
        this.CountryId = CountryId;
        this.PhoneNumber = PhoneNumber;
        this.Email = Email;

    }

    public int getCompanyId() {
        return CompanyId;
    }

    public void setCompanyId(int companyId) {
        CompanyId = companyId;
    }

    public String getAdministration() {
        return Administration;
    }

    public void setAdministration(String administration) {
        Administration = administration;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public int getStateId() {
        return StateId;
    }

    public void setStateId(int stateId) {
        StateId = stateId;
    }

    public int getZipcodeId() {
        return ZipcodeId;
    }

    public void setZipcodeId(int zipcodeId) {
        ZipcodeId = zipcodeId;
    }

    public int getCountryId() {
        return CountryId;
    }

    public void setCountryId(int countryId) {
        CountryId = countryId;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }


}
