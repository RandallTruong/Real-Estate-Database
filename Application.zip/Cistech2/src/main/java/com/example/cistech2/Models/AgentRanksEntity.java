package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "agentranks")
public class AgentRanksEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "rank_id")
    private int RankId;
    @Column(name = "rank")
    private String Rank;
    @Column(name = "description")
    private String Description;

    public AgentRanksEntity(){

    }

    public AgentRanksEntity(String rank, String description) {
        Rank = rank;
        Description = description;
    }

    public int getRankId() {
        return RankId;
    }

    public void setRankId(int rankId) {
        RankId = rankId;
    }

    public String getRank() {
        return Rank;
    }

    public void setRank(String rank) {
        Rank = rank;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }


}



