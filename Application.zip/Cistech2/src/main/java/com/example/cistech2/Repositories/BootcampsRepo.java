package com.example.cistech2.Repositories;

import com.example.cistech2.Models.BootcampsEntity;
import org.springframework.data.repository.CrudRepository;

public interface BootcampsRepo extends CrudRepository<BootcampsEntity, Integer> {

}