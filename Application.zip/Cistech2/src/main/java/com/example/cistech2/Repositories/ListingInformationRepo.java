package com.example.cistech2.Repositories;

import com.example.cistech2.Models.ListingInformationEntity;
import org.springframework.data.repository.CrudRepository;

public interface ListingInformationRepo extends CrudRepository<ListingInformationEntity, Integer> {

}

