package com.example.cistech2.Models;

import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "listinginformation")
public class ListingInformationEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "listing_id")
    private int ListingId;
    @Column(name = "client_id")
    private int ClientId;
    @Column(name = "property_id")
    private int PropertyId;
    @Column(name = "address")
    private String Address;
    @Column(name = "city")
    private String City;
    @Column(name = "state_id")
    private int StateId;
    @Column(name = "zipcode_id")
    private int ZipcodeId;
    @Column(name = "country_id")
    private int CountryId;
    @Column(name = "sqfeet")
    private int SQFeet;
    @Column(name= "numberofbedrooms")
    private int NumberOfBedrooms;
    @Column(name = "numberofbathrooms")
    private int NumberOfBathrooms;

    public ListingInformationEntity() {
    }

    public ListingInformationEntity(int clientId, int propertyId, String address, String city, int stateId,
                                    int zipcodeId, int countryId, int SQFeet, int numberOfBedrooms, int numberOfBathrooms) {
        ClientId = clientId;
        PropertyId = propertyId;
        Address = address;
        City = city;
        StateId = stateId;
        ZipcodeId = zipcodeId;
        CountryId = countryId;
        this.SQFeet = SQFeet;
        NumberOfBedrooms = numberOfBedrooms;
        NumberOfBathrooms = numberOfBathrooms;
    }


    public int getListingId() {
        return ListingId;
    }

    public void setListingId(int listingId) {
        ListingId = listingId;
    }

    public int getClientId() {
        return ClientId;
    }

    public void setClientId(int clientId) {
        ClientId = clientId;
    }

    public int getPropertyId() {
        return PropertyId;
    }

    public void setPropertyId(int propertyId) {
        PropertyId = propertyId;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public int getStateId() {
        return StateId;
    }

    public void setStateId(int stateId) {
        StateId = stateId;
    }

    public int getZipcodeId() {
        return ZipcodeId;
    }

    public void setZipcodeId(int zipcodeId) {
        ZipcodeId = zipcodeId;
    }

    public int getCountryId() {
        return CountryId;
    }

    public void setCountryId(int countryId) {
        CountryId = countryId;
    }

    public int getSQFeet() {
        return SQFeet;
    }

    public void setSQFeet(int SQFeet) {
        this.SQFeet = SQFeet;
    }

    public int getNumberOfBedrooms() {
        return NumberOfBedrooms;
    }

    public void setNumberOfBedrooms(int numberOfBedrooms) {
        NumberOfBedrooms = numberOfBedrooms;
    }

    public int getNumberOfBathrooms() {
        return NumberOfBathrooms;
    }

    public void setNumberOfBathrooms(int numberOfBathrooms) {
        NumberOfBathrooms = numberOfBathrooms;
    }
}
