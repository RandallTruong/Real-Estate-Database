package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "transactions")
public class TransactionsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "transaction_id")
    private int TransactionId;
    @Column(name = "sale_listing_id")
    private int SaleListingId;
    @Column(name = "payment_type_id")
    private int PaymentTypeId;
    @Column(name = "sold_price")
    private float SoldPrice;
    @Column(name = "comission_percentage")
    private int ComissionPercentage;
    @Column(name = "date")
    private String Date;

    public TransactionsEntity() {
    }

    public TransactionsEntity(int saleListingId, int paymentTypeId,
                              float soldPrice, int comissionPercentage, String date) {
        SaleListingId = saleListingId;
        PaymentTypeId = paymentTypeId;
        SoldPrice = soldPrice;
        ComissionPercentage = comissionPercentage;
        Date = date;
    }

    public int getTransactionId() {
        return TransactionId;
    }

    public void setTransactionId(int transactionId) {
        TransactionId = transactionId;
    }

    public int getSaleListingId() {
        return SaleListingId;
    }

    public void setSaleListingId(int saleListingId) {
        SaleListingId = saleListingId;
    }

    public int getPaymentTypeId() {
        return PaymentTypeId;
    }

    public void setPaymentTypeId(int paymentTypeId) {
        PaymentTypeId = paymentTypeId;
    }

    public float getSoldPrice() {
        return SoldPrice;
    }

    public void setSoldPrice(float soldPrice) {
        SoldPrice = soldPrice;
    }

    public int getComissionPercentage() {
        return ComissionPercentage;
    }

    public void setComissionPercentage(int comissionPercentage) {
        ComissionPercentage = comissionPercentage;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

}
