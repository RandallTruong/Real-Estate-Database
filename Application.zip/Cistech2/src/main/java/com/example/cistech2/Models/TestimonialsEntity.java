package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "testimonials")
public class TestimonialsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "testimonial_id")
    private int TestimonialId;
    @Column(name = "agent_id")
    private int AgentId;
    @Column(name = "rating_id")
    private int RatingId;
    @Column(name = "comment")
    private String Comment;
    @Column(name = "date")
    private String Date;

    public TestimonialsEntity() {
    }


    public TestimonialsEntity(int agentId, int ratingId, String comment, String date) {
        AgentId = agentId;
        RatingId = ratingId;
        Comment = comment;
        Date = date;
    }

    public int getTestimonialId() {
        return TestimonialId;
    }

    public void setTestimonialId(int testimonialId) {
        TestimonialId = testimonialId;
    }

    public int getAgentId() {
        return AgentId;
    }

    public void setAgentId(int agentId) {
        AgentId = agentId;
    }

    public int getRatingId() {
        return RatingId;
    }

    public void setRatingId(int ratingId) {
        RatingId = ratingId;
    }

    public String getComment() {
        return Comment;
    }

    public void setComment(String comment) {
        Comment = comment;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
