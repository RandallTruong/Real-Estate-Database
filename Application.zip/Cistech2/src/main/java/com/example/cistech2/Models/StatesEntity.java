package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "states")
public class StatesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "state_id")
    private int StateId;
    @Column(name = "state")
    private String State;

    public StatesEntity() {
    }

    public StatesEntity(String state) {
        State = state;
    }

    public int getStateId() {
        return StateId;
    }

    public void setStateId(int stateId) {
        StateId = stateId;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }
}
