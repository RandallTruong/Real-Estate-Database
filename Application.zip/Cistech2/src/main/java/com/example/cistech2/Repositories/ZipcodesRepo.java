package com.example.cistech2.Repositories;

import com.example.cistech2.Models.ZipcodesEntity;
import org.springframework.data.repository.CrudRepository;

public interface ZipcodesRepo extends CrudRepository<ZipcodesEntity, Integer> {
        }