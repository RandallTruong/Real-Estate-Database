package com.example.cistech2.Repositories;

import com.example.cistech2.Models.TerminatedAgentsEntity;
import org.springframework.data.repository.CrudRepository;

public interface TerminatedAgentsRepo extends CrudRepository<TerminatedAgentsEntity, Integer> {

}