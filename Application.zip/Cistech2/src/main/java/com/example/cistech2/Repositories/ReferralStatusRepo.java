package com.example.cistech2.Repositories;

import com.example.cistech2.Models.ReferralStatusEntity;
import org.springframework.data.repository.CrudRepository;

public interface ReferralStatusRepo extends CrudRepository<ReferralStatusEntity, Integer> {

}
