package com.example.cistech2.Repositories;

import com.example.cistech2.Models.PropertyTypeEntity;
import org.springframework.data.repository.CrudRepository;

public interface PropertyTypeRepo extends CrudRepository<PropertyTypeEntity, Integer> {

}
