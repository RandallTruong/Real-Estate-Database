package com.example.cistech2.Repositories;

import com.example.cistech2.Models.ProbationPeriodsEntity;
import org.springframework.data.repository.CrudRepository;

public interface ProbationPeriodsRepo extends CrudRepository<ProbationPeriodsEntity, Integer> {

}