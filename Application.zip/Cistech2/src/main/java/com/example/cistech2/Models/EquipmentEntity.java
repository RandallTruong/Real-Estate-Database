package com.example.cistech2.Models;

import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "equipment")
public class EquipmentEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "equipment_id")
    private int EquipmentId;
    @Column(name = "bootcamp_id")
    private int BootcampId;
    @Column(name = "equipment")
    private String Equipment;
    @Column(name = "value")
    private float Value;
    @Column(name = "quantity")
    private int quantity;


    public EquipmentEntity() {
    }

    public EquipmentEntity(int bootcampId, String equipment, float value, int quantity) {
        BootcampId = bootcampId;
        Equipment = equipment;
        Value = value;
        this.quantity = quantity;
    }

    public int getEquipmentId() {
        return EquipmentId;
    }

    public void setEquipmentId(int equipmentId) {
        EquipmentId = equipmentId;
    }

    public int getBootcampId() {
        return BootcampId;
    }

    public void setBootcampId(int bootcampId) {
        BootcampId = bootcampId;
    }

    public String getEquipment() {
        return Equipment;
    }

    public void setEquipment(String equipment) {
        Equipment = equipment;
    }

    public float getValue() {
        return Value;
    }

    public void setValue(float value) {
        Value = value;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }



}
