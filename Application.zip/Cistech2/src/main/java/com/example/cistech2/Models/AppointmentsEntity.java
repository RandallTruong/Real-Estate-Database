package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "appointments")
public class AppointmentsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "appointment_id")
    private int Appointment_id;
    @Column(name = "agent_id")
    private int AgentId;
    @Column(name = "client_id")
    private int ClientId;
    @Column(name = "topic_id")
    private int TopicId;
    @Column(name = "date")
    private String Date;
    @Column
    private String Time;

    public AppointmentsEntity(){

    }

    public AppointmentsEntity(int agentId, int clientId, int topicId, String date, String time) {
        AgentId = agentId;
        ClientId = clientId;
        TopicId = topicId;
        Date = date;
        Time = time;
    }

    public int getAppointment_id() {
        return Appointment_id;
    }

    public void setAppointment_id(int appointment_id) {
        Appointment_id = appointment_id;
    }

    public int getAgentId() {
        return AgentId;
    }

    public void setAgentId(int agentId) {
        AgentId = agentId;
    }

    public int getClientId() {
        return ClientId;
    }

    public void setClientId(int clientId) {
        ClientId = clientId;
    }

    public int getTopicId() {
        return TopicId;
    }

    public void setTopicId(int topicId) {
        TopicId = topicId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

}
