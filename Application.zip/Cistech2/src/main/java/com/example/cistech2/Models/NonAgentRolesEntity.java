package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "nonagentroles")
public class NonAgentRolesEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "team_member_id")
    private int TeamMemberId;
    @Column(name = "employee_id")
    private int EmployeeId;
    @Column(name = "role_type_id")
    private int RoleTypeId;
    @Column(name = "date")
    private String Date;

    public NonAgentRolesEntity() {
    }

    public NonAgentRolesEntity(int employeeId, int roleTypeId, String date) {
        EmployeeId = employeeId;
        RoleTypeId = roleTypeId;
        Date = date;
    }

    public int getTeamMemberId() {
        return TeamMemberId;
    }

    public void setTeamMemberId(int teamMemberId) {
        TeamMemberId = teamMemberId;
    }

    public int getEmployeeId() {
        return EmployeeId;
    }

    public void setEmployeeId(int employeeId) {
        EmployeeId = employeeId;
    }

    public int getRoleTypeId() {
        return RoleTypeId;
    }

    public void setRoleTypeId(int roleTypeId) {
        RoleTypeId = roleTypeId;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
