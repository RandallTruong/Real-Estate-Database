package com.example.cistech2.Models;
import javax.persistence.*;

@Entity
@Table(catalog = "cistech2db", schema = "dbo", name = "agents")
public class AgentsEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "agent_id")
    private int AgentId;
    @Column(name = "team_member_id")
    private int TeamMemberId;
    @Column(name = "certificate_id")
    private int CertificateId;
    @Column(name = "trec_license#")
    private String TrecLicense;
    @Column(name = "rank_id")
    private int RankId;
    @Column(name = "date")
    private String Date;

    public AgentsEntity(){

    }

    public AgentsEntity(int TeamMemberId, int certificateId, String trecLicense, int RankId, String date) {

        TeamMemberId = TeamMemberId;
        CertificateId = certificateId;
        TrecLicense = trecLicense;
        this.RankId = RankId;
        Date = date;
    }

    public int getAgentId() {
        return AgentId;
    }

    public void setAgentId(int agentId) {
        AgentId = agentId;
    }

    public int getTeamMemberId() {
        return TeamMemberId;
    }

    public void setTeamMemberId(int teamMemberId) {
        TeamMemberId = teamMemberId;
    }

    public int getCertificateId() {
        return CertificateId;
    }

    public void setCertificateId(int certificateId) {
        CertificateId = certificateId;
    }

    public String getTrecLicense() {
        return TrecLicense;
    }

    public void setTrecLicense(String trecLicense) {
        TrecLicense = trecLicense;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public int getRankId() {
        return RankId;
    }

    public void setRankId(int rankId) {
        RankId = rankId;
    }
}
