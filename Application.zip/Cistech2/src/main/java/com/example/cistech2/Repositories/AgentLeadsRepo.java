package com.example.cistech2.Repositories;

import com.example.cistech2.Models.AgentLeadsEntity;
import org.springframework.data.repository.CrudRepository;

public interface AgentLeadsRepo extends CrudRepository<AgentLeadsEntity, Integer> {

        }